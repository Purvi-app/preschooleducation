angular.module('starter.services', [])

.factory('Chats', function () {
    var mainCateory = [
        {
            "id": "1",
            "name": "Animal",
            "description": "Animal"
        },
        {
            "id": "2",
            "name": "Birds",
            "description": "Birds"
        },
        {
            "id": "3",
            "name": "Fruits",
            "description": "Fruits"
        },
        {
            "id": "4",
            "name": "vegetable",
            "description": "vegetable"
        },
        {
            "id": "5",
            "name": "utensils",
            "description": "utensils"
        },
        {
            "id": "6",
            "name": "country",
            "description": "country"
        },
        {
            "id": "7",
            "name": "number",
            "description": "number"
        },
        {
            "id": "8",
            "name": "color",
            "description": "color"
        },
        //{
        //    "id": "9",
        //    "name": "count",
        //    "description": "count"
        //},
        {
            "id": "10",
            "name": "shape",
            "description": "shape"
        },
        {
            "id": "11",
            "name": "vehicle",
            "description": "vehicle"
        },
        {
            "id": "12",
            "name": "body parts",
            "description": "body parts"
        },
        {
            "id": "13",
            "name": "flower",
            "description": "flower"
        },
        {
            "id": "14",
            "name": "months",
            "description": "months"
        },
        {
            "id": "15",
            "name": "stationery",
            "description": "stationery"
        },
        {
            "id": "16",
            "name": "Day",
            "description": "Day"
        },
        {
            "id": "17",
            "name": "good habits",
            "description": "good habits"
        },
        {
            "id": "18",
            "name": "occupation",
            "description": "occupation"
        },
        {
            "id": "19",
            "name": "computer parts",
            "description": "computer parts"
        },
        //{
        //    "id": "20",
        //    "name": "tablet",
        //    "description": "tablet"
        //},
        {
            "id": "21",
            "name": "bathroom accessories",
            "description": "bathroom accessories"
        },
        //{
        //    "id": "22",
        //    "name": "furniture",
        //    "description": "furniture"
        //},
        //{
        //    "id": "23",
        //    "name": "cars",
        //    "description": "cars"
        //},
        //{
        //    "id": "24",
        //    "name": "game",
        //    "description": "game"
        //},
        {
            "id": "25",
            "name": "insect",
            "description": "insect"
        },
        //{
        //    "id": "26",
        //    "name": "words",
        //    "description": "words"
        //},
        {
            "id": "27",
            "name": "family member",
            "description": "family member"
        },
        {
            "id": "28",
            "name": "household items",
            "description": "household items"
        },
        {
            "id": "29",
            "name": "jewelary",
            "description": "jewelary"
        },
        {
            "id": "30",
            "name": "Metal",
            "description": "Metal"
        },
        {
            "id": "31",
            "name": "Pet Animal",
            "description": "Pet Animal"
        },
        {
            "id": "32",
            "name": "Planet",
            "description": "Planet"
        },
        {
            "id": "33",
            "name": "Rainbow Color",
            "description": "Rainbow Color"
        },
        {
            "id": "34",
            "name": "Rasi",
            "description": "Rasi"
        },
        {
            "id": "35",
            "name": "Season name",
            "description": "Season name"
        },
        {
            "id": "36",
            "name": "Wild Animal",
            "description": "Wild Animal"
        },
        
    ];

    return {
        all: function () {
           
            return mainCateory;
        },
        remove: function (chat) {
            chats.splice(chats.indexOf(chat), 1);
        },
        get: function (chatid) {
            var data = [];
            switch (chatid) {
                case 1:
                    data = animal;
                    break;
                case 2:
                    data = bird;
                    break;
                case 3:
                    data = fruits;
                    break;
                case 4:
                    data = vegetable;
                    break;
                case 5:
                    data = utensil;
                    break;
                case 6:
                    data = country;
                    break;
                case 7:
                    data = count;
                    break;
                case 8:
                    data = color;
                    break;
                case 9:
                    data = count;
                    break;
                case 10:
                    data = shapes;
                    break;
                case 11:
                    data = vehicle;
                    break;
                case 12:
                    data = body_parts;
                    break;
                case 13:
                    data = flower;
                    break;

                case 14:
                    data = months;
                    break;

                case 15:
                    data = stationary;
                    break;
                case 16:
                    data = days;
                    break;
                case 17:
                    data = good_habit;
                    break;
                case 18:
                    data = occuption_kids;
                    break;
                case 19:
                    data = computer_parts;
                    break;
                case 20:
                    data = "tablet";
                    break;
                case 21:
                    data =bathroom_ass;
                    break;
                case 22:
                    data = "furniture";
                    break;
                case 23:
                    data = "cars";
                    break;
                case 24:
                    data = "game";
                    break;
                case 25:
                    data = insect;
                    break;
                case 26:
                    data = "words";
                    break;
                case 27:
                    data = family_member;
                    break;
                case 28:
                    data = houseItems;
                    break;
                case 29:
                    data = jewelry;
                    break;
                case 30:
                    data = metal;
                    break;
                case 31:
                    data = pet_animal;
                    break;
                case 32:
                    data = planet;
                    break;
                case 33:
                    data = rainbow_color;
                    break;
                case 34:
                    data = rasi;
                    break;
                case 35:
                    data = season_name;
                    break;
                case 36:
                    data = wild_animal;
                    break;


            }
         

            return data;
     
        }
    };


});


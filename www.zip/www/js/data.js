﻿var mainCateory = [
        {
            "id": "1",
            "name": "Animal",
            "description": "Animal"
        },
        {
            "id": "2",
            "name": "Birds",
            "description": "Birds"
        },
        {
            "id": "3",
            "name": "Fruits",
            "description": "Fruits"
        },
        {
            "id": "4",
            "name": "vegetable",
            "description": "vegetable"
        },
        {
            "id": "5",
            "name": "utensils",
            "description": "utensils"
        },
        {
            "id": "6",
            "name": "country",
            "description": "country"
        },
        {
            "id": "7",
            "name": "number",
            "description": "number"
        },
        {
            "id": "8",
            "name": "color",
            "description": "color"
        },
        {
            "id": "9",
            "name": "count",
            "description": "count"
        },
        {
            "id": "10",
            "name": "shape",
            "description": "shape"
        },
        {
            "id": "11",
            "name": "vehicle",
            "description": "vehicle"
        },
        {
            "id": "12",
            "name": "body parts",
            "description": "body parts"
        },
        {
            "id": "13",
            "name": "flower",
            "description": "flower"
        },
        {
            "id": "14",
            "name": "months",
            "description": "months"
        },
        {
            "id": "15",
            "name": "stationery",
            "description": "stationery"
        },
        {
            "id": "16",
            "name": "Day",
            "description": "Day"
        },
        {
            "id": "17",
            "name": "good habits",
            "description": "good habits"
        },
        {
            "id": "18",
            "name": "occupation",
            "description": "occupation"
        },
        {
            "id": "19",
            "name": "computer parts",
            "description": "computer parts"
        },
        {
            "id": "20",
            "name": "tablet",
            "description": "tablet"
        },
        {
            "id": "21",
            "name": "bathroom accessories",
            "description": "bathroom accessories"
        },
        {
            "id": "22",
            "name": "furniture",
            "description": "furniture"
        },
        {
            "id": "23",
            "name": "cars",
            "description": "cars"
        },
        {
            "id": "24",
            "name": "game",
            "description": "game"
        },
        {
            "id": "25",
            "name": "insect",
            "description": "insect"
        },
        {
            "id": "26",
            "name": "words",
            "description": "words"
        },
        {
            "id": "27",
            "name": "family member",
            "description": "family member"
        },
        {
            "id": "28",
            "name": "household items",
            "description": "household items"
        },
        {
            "id": "29",
            "name": "jewelary",
            "description": "jewelary"
        },
        {
            "id": "30",
            "name": "Metal",
            "description": "Metal"
        },
        {
            "id": "31",
            "name": "Pet Animal",
            "description": "Pet Animal"
        },
        {
            "id": "32",
            "name": "Planet",
            "description": "Planet"
        },
        {
            "id": "33",
            "name": "Rainbow Color",
            "description": "Rainbow Color"
        },
        {
            "id": "34",
            "name": "Rasi",
            "description": "Rasi"
        },
        {
            "id": "35",
            "name": "Season name",
            "description": "Season name"
        },
        {
            "id": "36",
            "name": "Wild Animal",
            "description": "Wild Animal"
        },
        {
            "description": "1"
        }
    ];

var animal = [
        {
            "id": "1",
            "name": "Aardvark",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "—",
            "Collateral adjective": "orycteropodian"
        },
        {
            "id": "2",
            "name": "Albatross",
            "Young": "chick",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "flock",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "rookery"
        },
        {
            "Collective noun": "gam (when searching for mates)"
        },
        {
            "id": "3",
            "name": "Alligator",
            "Young": "hatchling",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "congregation",
            "Collateral adjective": "eusuchian"
        },
        {
            "id": "4",
            "name": "Alpaca",
            "Young": "cria",
            "Female": "?",
            "Male": "?",
            "Collective noun": "herd",
            "Collateral adjective": "camelid"
        },
        {
            "id": "5",
            "name": "Ant",
            "Young": "larva",
            "Female": "queen",
            "Male": "drone",
            "Collective noun": "army",
            "Collateral adjective": "formic"
        },
        {
            "Young": "pupa",
            "Female": "worker",
            "Collective noun": "bike",
            "Collateral adjective": "myrmecine"
        },
        {
            "Female": "gyne",
            "Collective noun": "colony"
        },
        {
            "Collective noun": "nest"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "6",
            "name": "Anteater",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "N/A",
            "Collateral adjective": "?"
        },
        {
            "id": "7",
            "name": "Antelope",
            "Young": "calf",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "herd",
            "Collateral adjective": "alcelaphine"
        },
        {
            "Collective noun": "cluster",
            "Collateral adjective": "bubaline"
        },
        {
            "Collective noun": "tribe",
            "Collateral adjective": "antilopine"
        },
        {
            "id": "8",
            "name": "Ape",
            "Young": "infant",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "shrewdness",
            "Collateral adjective": "simian"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "9",
            "name": "Armadillo",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "N/A",
            "Collateral adjective": "cingulatan"
        },
        {
            "Young": "baby"
        },
        {
            "id": "10",
            "name": "Ass/Donkey",
            "Young": "foal",
            "Female": "jenny",
            "Male": "jack",
            "Collective noun": "herd",
            "Collateral adjective": "asinine"
        },
        {
            "Collective noun": "coffle"
        },
        {
            "Collective noun": "drove"
        },
        {
            "Collective noun": "pace"
        },
        {
            "id": "11",
            "name": "Baboon",
            "Young": "infant",
            "Female": "N/A",
            "Male": "?",
            "Collective noun": "flange",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "tribe"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "12",
            "name": "Badger",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "cete",
            "Collateral adjective": "musteline"
        },
        {
            "Young": "kit",
            "Collective noun": "clan"
        },
        {
            "Collective noun": "colony"
        },
        {
            "Collective noun": "company"
        },
        {
            "id": "13",
            "name": "Barracuda",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "school",
            "Collateral adjective": "percesocine"
        },
        {
            "id": "14",
            "name": "Bat",
            "Young": "pup",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "cloud",
            "Collateral adjective": "pteropine"
        },
        {
            "Collective noun": "colony",
            "Collateral adjective": "noctillionine"
        },
        {
            "Collective noun": "flock"
        },
        {
            "id": "15",
            "name": "Bear",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "sleuth",
            "Collateral adjective": "ursine"
        },
        {
            "Collective noun": "sloth"
        },
        {
            "id": "16",
            "name": "Beaver",
            "Young": "kit",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "family"
        },
        {
            "Young": "kitten",
            "Collective noun": "colony"
        },
        {
            "Young": "pup"
        },
        {
            "id": "17",
            "name": "Bee",
            "Young": "larva",
            "Female": "queen",
            "Male": "drone",
            "Collective noun": "cast (a second swarm)",
            "Collateral adjective": "apic"
        },
        {
            "Young": "pupa",
            "Female": "worker",
            "Collective noun": "cluster (of workers around the queen)",
            "Collateral adjective": "apian"
        },
        {
            "Collective noun": "colony",
            "Collateral adjective": "apiarian"
        },
        {
            "Collective noun": "drift"
        },
        {
            "Collective noun": "erst"
        },
        {
            "Collective noun": "grist"
        },
        {
            "Collective noun": "hive"
        },
        {
            "Collective noun": "nest"
        },
        {
            "Collective noun": "rabble"
        },
        {
            "Collective noun": "stand"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "18",
            "name": "Bison",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "bovine"
        },
        {
            "Collateral adjective": "bubaline"
        },
        {
            "id": "19",
            "name": "Boar (wild pig)",
            "Young": "piglet",
            "Female": "?",
            "Male": "?",
            "Collective noun": "herd",
            "Collateral adjective": "?"
        },
        {
            "name": "Also see Pig",
            "Young": "farrow",
            "Collective noun": "singular"
        },
        {
            "Young": "shoat/shote (just weaned)",
            "Collective noun": "sounder"
        },
        {
            "id": "20",
            "name": "Buffalo, African (for American buffalo, see Bison",
            "Young": "calf",
            "Female": "cow, heifer",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "troop"
        },
        {
            "Collective noun": "gang"
        },
        {
            "Collective noun": "obstinancy"
        },
        {
            "id": "21",
            "name": "Galago",
            "Young": "infant",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "gathering",
            "Collateral adjective": "galagine"
        },
        {
            "Collective noun": "plot"
        },
        {
            "id": "22",
            "name": "Butterfly",
            "Young": "caterpillar",
            "Female": "?",
            "Male": "?",
            "Collective noun": "flight",
            "Collateral adjective": "pieridine"
        },
        {
            "Young": "larva",
            "Collective noun": "flutter",
            "Collateral adjective": "pierine"
        },
        {
            "Young": "pupa",
            "Collective noun": "rabble",
            "Collateral adjective": "lepidopteran"
        },
        {
            "Young": "chrysalis"
        },
        {
            "id": "23",
            "name": "Camel",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "caravan",
            "Collateral adjective": "camelid"
        },
        {
            "Collective noun": "flock",
            "Collateral adjective": "cameline"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "train"
        },
        {
            "id": "24",
            "name": "Caribou",
            "Young": "calf",
            "Female": "?",
            "Male": "?",
            "Collective noun": "herd",
            "Collateral adjective": "rangiferine"
        },
        {
            "id": "25",
            "name": "Cat",
            "Young": "kitten",
            "Female": "molly",
            "Male": "tom",
            "Collective noun": "clowder",
            "Collateral adjective": "feline"
        },
        {
            "Young": "kit",
            "Female": "queen",
            "Male": "gib (castrated male)",
            "Collective noun": "cluster"
        },
        {
            "Female": "pussy",
            "Collective noun": "clutter"
        },
        {
            "Collective noun": "glaring"
        },
        {
            "Collective noun": "pounce"
        },
        {
            "Collective noun": "kindle (kittens)"
        },
        {
            "Collective noun": "litter (kittens)"
        },
        {
            "id": "26",
            "name": "Caterpillar",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "army",
            "Collateral adjective": "?"
        },
        {
            "id": "27",
            "name": "Cattle",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "bovine",
            "Culinary noun for meat": "beef"
        },
        {
            "Collective noun": "drove",
            "Collateral adjective": "taurine (male)",
            "Culinary noun for meat": "veal"
        },
        {
            "Collective noun": "mob",
            "Collateral adjective": "vaccine (female)"
        },
        {
            "Collective noun": "team (Oxen)",
            "Collateral adjective": "vituline (young)"
        },
        {
            "id": "28",
            "name": "Chamois",
            "Young": "calf",
            "Female": "doe",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "rupicaprine"
        },
        {
            "id": "29",
            "name": "Cheetah",
            "Young": "cub",
            "Female": "?",
            "Male": "?",
            "Collective noun": "coalition (male)",
            "Collateral adjective": "?"
        },
        {
            "id": "30",
            "name": "Chicken",
            "Young": "chick",
            "Female": "hen",
            "Male": "rooster",
            "Collective noun": "flock",
            "Collateral adjective": "galline",
            "Culinary noun for meat": "poultry"
        },
        {
            "Female": "pullet",
            "Male": "cock",
            "Collective noun": "brood"
        },
        {
            "Male": "cockerel",
            "Collective noun": "peep (chicks)"
        },
        {
            "Male": "capon (castrated male)",
            "Collective noun": "clutch (eggs)"
        },
        {
            "id": "31",
            "name": "Chimpanzee",
            "Young": "infant",
            "Female": "empress",
            "Male": "blackback",
            "Collective noun": "troop",
            "Collateral adjective": "panine"
        },
        {
            "Collective noun": "group"
        },
        {
            "Collective noun": "harem"
        },
        {
            "id": "32",
            "name": "Chinchilla",
            "Young": "kit",
            "Female": "velvet",
            "Male": "boar",
            "Collective noun": "herd",
            "Collateral adjective": "chinchilline"
        },
        {
            "Female": "sow",
            "Male": "bull",
            "Collective noun": "colony"
        },
        {
            "id": "33",
            "name": "Chough",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "chattering",
            "Collateral adjective": "corvine"
        },
        {
            "Collective noun": "clattering"
        },
        {
            "id": "34",
            "name": "Clam",
            "Young": "larva",
            "Female": "?",
            "Male": "?",
            "Collective noun": "bed",
            "Collateral adjective": "?"
        },
        {
            "id": "35",
            "name": "Cobra",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "quiver",
            "Collateral adjective": "elapid"
        },
        {
            "id": "36",
            "name": "Cockroach",
            "Young": "nymph",
            "Female": "?",
            "Male": "?",
            "Collective noun": "intrusion",
            "Collateral adjective": "blattid"
        },
        {
            "id": "37",
            "name": "Cod",
            "Young": "codling",
            "Female": "?",
            "Male": "?",
            "Collective noun": "school",
            "Collateral adjective": "gadoid"
        },
        {
            "Young": "sprat",
            "Collateral adjective": "gadine"
        },
        {
            "id": "38",
            "name": "Cormorant",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "gulp"
        },
        {
            "Young": "shaglet",
            "Collective noun": "flight"
        },
        {
            "id": "39",
            "name": "Coyote",
            "Young": "cub",
            "Female": "bitch",
            "Male": "dog",
            "Collective noun": "pack",
            "Collateral adjective": "canine"
        },
        {
            "Young": "pup",
            "Collective noun": "train"
        },
        {
            "Young": "whelp",
            "Collective noun": "band"
        },
        {
            "id": "40",
            "name": "Crab",
            "Young": "N/A",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "cast",
            "Collateral adjective": "cancrine"
        },
        {
            "Female": "jenny",
            "Male": "jimmy",
            "Collective noun": "consortium"
        },
        {
            "id": "41",
            "name": "Crane",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "herd",
            "Collateral adjective": "alectorine"
        },
        {
            "Young": "colt",
            "Collective noun": "sedge"
        },
        {
            "Collective noun": "siege"
        },
        {
            "id": "42",
            "name": "Crocodile",
            "Young": "hatchling",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "bask",
            "Collateral adjective": "crocodilian"
        },
        {
            "Collective noun": "congregation"
        },
        {
            "Collective noun": "float"
        },
        {
            "Collective noun": "nest"
        },
        {
            "id": "43",
            "name": "Crow",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "horde",
            "Collateral adjective": "corvine"
        },
        {
            "Collective noun": "hover"
        },
        {
            "Collective noun": "murder"
        },
        {
            "id": "44",
            "name": "Curlew",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "herd",
            "Collateral adjective": "?"
        },
        {
            "id": "45",
            "name": "Deer",
            "Young": "calf",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "bunch",
            "Collateral adjective": "cervine",
            "Culinary noun for meat": "venison"
        },
        {
            "Young": "fawn",
            "Female": "hind",
            "Male": "stag",
            "Collective noun": "herd",
            "Collateral adjective": "elaphine",
            "Culinary noun for meat": "humble (organ meat)"
        },
        {
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "mob"
        },
        {
            "Male": "hart (red deer)",
            "Collective noun": "rangale"
        },
        {
            "Collective noun": "clash"
        },
        {
            "Collective noun": "gang"
        },
        {
            "Collective noun": "leash"
        },
        {
            "Collective noun": "(buck) brace"
        },
        {
            "Collective noun": "(roe) bevy"
        },
        {
            "id": "46",
            "name": "Dinosaur",
            "Young": "hatchling",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd (herbivores)",
            "Collateral adjective": "dinosaurian"
        },
        {
            "Young": "juvenile",
            "Collective noun": "pack (carnivores)"
        },
        {
            "id": "47",
            "name": "Dog",
            "Young": "pup",
            "Female": "bitch",
            "Male": "dog",
            "Collective noun": "pack (wild)",
            "Collateral adjective": "canine"
        },
        {
            "Young": "puppy",
            "Female": "dam",
            "Male": "stud",
            "Collective noun": "kennel"
        },
        {
            "Young": "whelp",
            "Male": "sire",
            "Collective noun": "legion"
        },
        {
            "Collective noun": "mute"
        },
        {
            "Collective noun": "litter (young)"
        },
        {
            "Collective noun": "cowardice (curs)"
        },
        {
            "Collective noun": "comedy (boxers)"
        },
        {
            "Collective noun": "cry (hounds)"
        },
        {
            "id": "48",
            "name": "Dogfish",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "troop",
            "Collateral adjective": "?",
            "Culinary noun for meat": "capeshark (USA)"
        },
        {
            "Culinary noun for meat": "rock salmon (UK)"
        },
        {
            "Culinary noun for meat": "flake (UK, AUS)"
        },
        {
            "Culinary noun for meat": "huss (UK)"
        },
        {
            "Culinary noun for meat": "rigg (UK)"
        },
        {
            "Culinary noun for meat": "kahada (CAN)"
        },
        {
            "id": "49",
            "name": "Dolphin",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "school",
            "Collateral adjective": "delphine"
        },
        {
            "Young": "pup",
            "Collective noun": "pod"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "team"
        },
        {
            "Collective noun": "alliance (male)"
        },
        {
            "Collective noun": "party (female)"
        },
        {
            "id": "50",
            "name": "Donkey - See Ass",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "?"
        },
        {
            "id": "51",
            "name": "Dotterel",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "trip",
            "Collateral adjective": "?"
        },
        {
            "id": "52",
            "name": "Dove",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "arc",
            "Collateral adjective": "columbine"
        },
        {
            "Collective noun": "bevy"
        },
        {
            "Collective noun": "cote"
        },
        {
            "Collective noun": "dole"
        },
        {
            "Collective noun": "dule"
        },
        {
            "Collective noun": "flight"
        },
        {
            "Collective noun": "paddling"
        },
        {
            "Collective noun": "piteousness"
        },
        {
            "Collective noun": "pitying"
        },
        {
            "id": "53",
            "name": "Dragonfly",
            "Young": "nymph",
            "Female": "queen",
            "Male": "king",
            "Collective noun": "cluster",
            "Collateral adjective": "anisopteran"
        },
        {
            "Male": "drake",
            "Collective noun": "flight"
        },
        {
            "id": "54",
            "name": "Duck",
            "Young": "duckling",
            "Female": "duck",
            "Male": "drake",
            "Collective noun": "On land",
            "Collateral adjective": "anatine",
            "Culinary noun for meat": "poultry"
        },
        {
            "name": "Also see Mallard",
            "Female": "hen",
            "Collective noun": "flock",
            "Collateral adjective": "fuliguline"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "badling"
        },
        {
            "Collective noun": "brace"
        },
        {
            "Collective noun": "safe"
        },
        {
            "Collective noun": "sord"
        },
        {
            "Collective noun": "sore"
        },
        {
            "Collective noun": "waddling"
        },
        {
            "Collective noun": "On water"
        },
        {
            "Collective noun": "bunch"
        },
        {
            "Collective noun": "paddling"
        },
        {
            "Collective noun": "raft"
        },
        {
            "Collective noun": "In flight"
        },
        {
            "Collective noun": "skein"
        },
        {
            "Collective noun": "string"
        },
        {
            "Collective noun": "team"
        },
        {
            "id": "55",
            "name": "Dugong",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "dugongine"
        },
        {
            "id": "56",
            "name": "Dunlin",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "fling",
            "Collateral adjective": "?"
        },
        {
            "id": "57",
            "name": "Eagle",
            "Young": "eaglet",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "convocation",
            "Collateral adjective": "aquiline"
        },
        {
            "Young": "fledgling"
        },
        {
            "id": "58",
            "name": "Echidna",
            "Young": "puggle",
            "Female": "?",
            "Male": "?",
            "Collective noun": "—",
            "Collateral adjective": "tachyglossine"
        },
        {
            "Young": "(in common use, but not scientifically endorsed)"
        },
        {
            "id": "59",
            "name": "Eel",
            "Young": "leptocephalus (larva)",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "array",
            "Collateral adjective": "anguilline"
        },
        {
            "Young": "elver (juvenile)",
            "Collective noun": "bed"
        },
        {
            "Collective noun": "cell"
        },
        {
            "Collective noun": "fry"
        },
        {
            "Collective noun": "pipe"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "60",
            "name": "Eland",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "?"
        },
        {
            "id": "61",
            "name": "Elephant",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "elephantine"
        },
        {
            "Collective noun": "memory",
            "Collateral adjective": "proboscine"
        },
        {
            "Collective noun": "parade",
            "Collateral adjective": "proboscidean"
        },
        {
            "id": "62",
            "name": "Elephant seal",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "miroungan"
        },
        {
            "Collective noun": "pack"
        },
        {
            "Collective noun": "arrangement"
        },
        {
            "id": "63",
            "name": "Elk (wapiti)",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "gang",
            "Collateral adjective": "cervine",
            "Culinary noun for meat": "venison"
        },
        {
            "Collective noun": "herd"
        },
        {
            "id": "64",
            "name": "Emu",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "mob",
            "Collateral adjective": "?"
        },
        {
            "Young": "hatchling"
        },
        {
            "id": "65",
            "name": "Falcon",
            "Young": "eyass/eyas",
            "Female": "falcon",
            "Male": "tiercel",
            "Collective noun": "cast",
            "Collateral adjective": "acciptrine"
        },
        {
            "Male": "tercel"
        },
        {
            "Male": "terzel"
        },
        {
            "id": "66",
            "name": "Ferret",
            "Young": "kit",
            "Female": "jill",
            "Male": "hob",
            "Collective noun": "busyness",
            "Collateral adjective": "musteline"
        },
        {
            "Collective noun": "business"
        },
        {
            "Collective noun": "cast"
        },
        {
            "Collective noun": "fesnyng"
        },
        {
            "Collective noun": "fesynes"
        },
        {
            "id": "67",
            "name": "Finch",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "charm",
            "Collateral adjective": "fringilline"
        },
        {
            "Collective noun": "quiver"
        },
        {
            "id": "68",
            "name": "Fish",
            "Young": "fry",
            "Female": "?",
            "Male": "?",
            "Collective noun": "draft",
            "Collateral adjective": "piscine"
        },
        {
            "Young": "fingerling",
            "Collective noun": "nest"
        },
        {
            "Collective noun": "run"
        },
        {
            "Collective noun": "school"
        },
        {
            "Collective noun": "shoal"
        },
        {
            "Collective noun": "When caught"
        },
        {
            "Collective noun": "catch"
        },
        {
            "Collective noun": "drought"
        },
        {
            "Collective noun": "haul"
        },
        {
            "id": "69",
            "name": "Flamingo",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "stand",
            "Collateral adjective": "phoenicopterine"
        },
        {
            "Collective noun": "flamboyance"
        },
        {
            "id": "70",
            "name": "Fly",
            "Young": "maggot",
            "Female": "?",
            "Male": "?",
            "Collective noun": "business",
            "Collateral adjective": "dipterous"
        },
        {
            "Collective noun": "cloud"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "71",
            "name": "Fox",
            "Young": "cub",
            "Female": "vixen",
            "Male": "tod",
            "Collective noun": "earth",
            "Collateral adjective": "vulpine"
        },
        {
            "Young": "kit",
            "Male": "dog",
            "Collective noun": "lead"
        },
        {
            "Young": "pup",
            "Male": "reynard",
            "Collective noun": "leash"
        },
        {
            "Collective noun": "skulk"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "72",
            "name": "Frog",
            "Young": "polliwog",
            "Female": "-",
            "Male": "-",
            "Collective noun": "army",
            "Collateral adjective": "ranine"
        },
        {
            "Young": "tadpole",
            "Collective noun": "colony"
        },
        {
            "Young": "froglet",
            "Collective noun": "knot"
        },
        {
            "Collective noun": "bundle"
        },
        {
            "id": "73",
            "name": "Gaur",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "bovine",
            "Culinary noun for meat": "garabeef"
        },
        {
            "Collateral adjective": "gaurine"
        },
        {
            "id": "74",
            "name": "Gazelle",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "gazelline"
        },
        {
            "id": "75",
            "name": "Gerbil",
            "Young": "pup",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "horde",
            "Collateral adjective": "cricetine"
        },
        {
            "id": "76",
            "name": "Giant Panda",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "sleuth",
            "Collateral adjective": "ailuropodine"
        },
        {
            "id": "77",
            "name": "Giraffe",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "giraffine"
        },
        {
            "Collective noun": "corps"
        },
        {
            "Collective noun": "tower"
        },
        {
            "id": "78",
            "name": "Gnat",
            "Young": "larva",
            "Female": "?",
            "Male": "?",
            "Collective noun": "cloud",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "horde"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "79",
            "name": "Gnu",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd"
        },
        {
            "Collective noun": "implausibility"
        },
        {
            "id": "80",
            "name": "Goat",
            "Young": "kid",
            "Female": "nanny",
            "Male": "billy",
            "Collective noun": "drove",
            "Collateral adjective": "caprine",
            "Culinary noun for meat": "chevon"
        },
        {
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "flock",
            "Collateral adjective": "hircine",
            "Culinary noun for meat": "cabrito"
        },
        {
            "Female": "doeling",
            "Male": "buckling",
            "Collective noun": "herd",
            "Culinary noun for meat": "mutton"
        },
        {
            "Collective noun": "mob"
        },
        {
            "Collective noun": "tribe"
        },
        {
            "Collective noun": "trip"
        },
        {
            "id": "81",
            "name": "Goose",
            "Young": "gosling",
            "Female": "goose",
            "Male": "gander",
            "Collective noun": "On land",
            "Collateral adjective": "anatine",
            "Culinary noun for meat": "poultry"
        },
        {
            "Collective noun": "corps",
            "Collateral adjective": "anserine"
        },
        {
            "Collective noun": "flock"
        },
        {
            "Collective noun": "gaggle"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "In flight"
        },
        {
            "Collective noun": "skein"
        },
        {
            "Collective noun": "team"
        },
        {
            "Collective noun": "wedge"
        },
        {
            "id": "82",
            "name": "Goldfinch",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "charm",
            "Collateral adjective": "cardueline"
        },
        {
            "id": "83",
            "name": "Goldfish",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "glint",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "troubling"
        },
        {
            "id": "84",
            "name": "Gorilla",
            "Young": "infant",
            "Female": "N/A",
            "Male": "blackback",
            "Collective noun": "troop",
            "Collateral adjective": "simian"
        },
        {
            "Male": "silverback",
            "Collective noun": "band"
        },
        {
            "Collective noun": "whoop"
        },
        {
            "id": "85",
            "name": "Goshawk",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "flight",
            "Collateral adjective": "?"
        },
        {
            "id": "86",
            "name": "Grasshopper",
            "Young": "nymph",
            "Female": "?",
            "Male": "?",
            "Collective noun": "cloud",
            "Collateral adjective": "caeliferian"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "87",
            "name": "Grouse",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "covey",
            "Collateral adjective": "tetraonine"
        },
        {
            "id": "88",
            "name": "Guanaco",
            "Young": "chulengo",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "camelid"
        },
        {
            "id": "89",
            "name": "Guinea fowl",
            "Young": "keet",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "confusion",
            "Collateral adjective": "numidine",
            "Culinary noun for meat": "poultry"
        },
        {
            "Collective noun": "Rasp"
        },
        {
            "Collective noun": "flock"
        },
        {
            "id": "90",
            "name": "Guinea pig",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "herd",
            "Collateral adjective": "?",
            "Culinary noun for meat": "cui"
        },
        {
            "id": "91",
            "name": "Gull",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "colony",
            "Collateral adjective": "larine"
        },
        {
            "Collective noun": "flock"
        },
        {
            "id": "92",
            "name": "Hamster",
            "Young": "pup",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "horde",
            "Collateral adjective": "cricetid"
        },
        {
            "id": "93",
            "name": "Hare",
            "Young": "leveret",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "band",
            "Collateral adjective": "leverine"
        },
        {
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "down",
            "Collateral adjective": "leporine"
        },
        {
            "Collective noun": "drove"
        },
        {
            "Collective noun": "flick"
        },
        {
            "Collective noun": "husk"
        },
        {
            "id": "94",
            "name": "Hawk",
            "Young": "eyas",
            "Female": "hen",
            "Male": "tiercel",
            "Collective noun": "boil",
            "Collateral adjective": "accipitrine"
        },
        {
            "Collective noun": "cast",
            "Collateral adjective": "falconine"
        },
        {
            "Collective noun": "kettle"
        },
        {
            "id": "95",
            "name": "Hedgehog",
            "Young": "hoglet",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "array",
            "Collateral adjective": "erinaceine"
        },
        {
            "Young": "piglet"
        },
        {
            "Young": "pup"
        },
        {
            "id": "96",
            "name": "Heron",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flight",
            "Collateral adjective": "ardeidine"
        },
        {
            "Collective noun": "sedge"
        },
        {
            "Collective noun": "sege"
        },
        {
            "Collective noun": "siege"
        },
        {
            "id": "97",
            "name": "Herring",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "army",
            "Collateral adjective": "clupeidean"
        },
        {
            "Collective noun": "glean"
        },
        {
            "Collective noun": "shoal"
        },
        {
            "id": "98",
            "name": "Hippopotamus",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "bloat",
            "Collateral adjective": "hippopotamine"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "thunder"
        },
        {
            "id": "99",
            "name": "Hornet",
            "Young": "larvae",
            "Female": "queen",
            "Male": "drone",
            "Collective noun": "nest",
            "Collateral adjective": "vespine"
        },
        {
            "Young": "pupae",
            "Collective noun": "swarm"
        },
        {
            "id": "100",
            "name": "Horse",
            "Young": "foal",
            "Female": "mare",
            "Male": "stallion",
            "Collective noun": "stable",
            "Collateral adjective": "equine"
        },
        {
            "Young": "colt (male)",
            "Female": "dam",
            "Male": "stud",
            "Collective noun": "stud"
        },
        {
            "Young": "filly (female)",
            "Collective noun": "harras"
        },
        {
            "Young": "gelding (castrated male)",
            "Collective noun": "herd (wild horses)"
        },
        {
            "Collective noun": "band (wild horses)"
        },
        {
            "Collective noun": "team (work horses)"
        },
        {
            "Collective noun": "rag (colts)"
        },
        {
            "Collective noun": "string (ponies)"
        },
        {
            "Collective noun": "field (racehorses),"
        },
        {
            "Collective noun": "ramada (group of horses owned by a single cowboy)"
        },
        {
            "id": "101",
            "name": "Human",
            "Young": "baby",
            "Female": "woman",
            "Male": "man",
            "Collective noun": "group",
            "Collateral adjective": "human",
            "Culinary noun for meat": "long pig"
        },
        {
            "Young": "child",
            "Collective noun": "family",
            "Culinary noun for meat": "(See cannibalism)"
        },
        {
            "Young": "girl",
            "Collective noun": "band"
        },
        {
            "Young": "boy",
            "Collective noun": "crowd"
        },
        {
            "Collective noun": "clan"
        },
        {
            "Collective noun": "tribe"
        },
        {
            "id": "102",
            "name": "Hummingbird",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "charm",
            "Collateral adjective": "trochiline"
        },
        {
            "Collateral adjective": "trochilidine"
        },
        {
            "id": "103",
            "name": "Hyena",
            "Young": "cub",
            "Female": "bitch",
            "Male": "dog",
            "Collective noun": "clan",
            "Collateral adjective": "hyenine"
        },
        {
            "Young": "pup",
            "Collective noun": "cackle"
        },
        {
            "Young": "whelp"
        },
        {
            "id": "104",
            "name": "Jackal",
            "Young": "pup",
            "Female": "?",
            "Male": "?",
            "Collective noun": "pack",
            "Collateral adjective": "?"
        },
        {
            "id": "105",
            "name": "Jaguar",
            "Young": "cub",
            "Female": "?",
            "Male": "?",
            "Collective noun": "prowl",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "leap"
        },
        {
            "id": "106",
            "name": "Jay",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "band",
            "Collateral adjective": "corvine"
        },
        {
            "Collective noun": "party"
        },
        {
            "Collective noun": "scold"
        },
        {
            "id": "107",
            "name": "Jay, Blue",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "charm",
            "Collateral adjective": "corvine"
        },
        {
            "id": "108",
            "name": "Jellyfish",
            "Young": "planula",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "bloom",
            "Collateral adjective": "scyphozoan"
        },
        {
            "Young": "polyp",
            "Collective noun": "fluther"
        },
        {
            "Young": "ephyra",
            "Collective noun": "smack"
        },
        {
            "Collective noun": "smuth"
        },
        {
            "id": "109",
            "name": "Kangaroo",
            "Young": "joey",
            "Female": "flyer",
            "Male": "boomer",
            "Collective noun": "court",
            "Collateral adjective": "macropodine"
        },
        {
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "herd"
        },
        {
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "mob"
        },
        {
            "Female": "roo",
            "Collective noun": "troop"
        },
        {
            "id": "110",
            "name": "Koala",
            "Young": "joey",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "colony",
            "Collateral adjective": "phascolarctine"
        },
        {
            "id": "111",
            "name": "Komodo dragon",
            "Young": "hatchling",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "bank",
            "Collateral adjective": "varanine"
        },
        {
            "Young": "chick",
            "Female": "hen",
            "Male": "cock"
        },
        {
            "Young": "calf"
        },
        {
            "id": "112",
            "name": "Kouprey",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "sauveline"
        },
        {
            "Collateral adjective": "bovine"
        },
        {
            "id": "113",
            "name": "Kudu",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "tragelaphine"
        },
        {
            "id": "114",
            "name": "Lapwing",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "deceit",
            "Collateral adjective": "vanelline"
        },
        {
            "Collective noun": "desert"
        },
        {
            "id": "115",
            "name": "Lark",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "exaltation",
            "Collateral adjective": "alaudine"
        },
        {
            "id": "116",
            "name": "Lemur",
            "Young": "infant",
            "Female": "?",
            "Male": "?",
            "Collective noun": "congress",
            "Collateral adjective": "lemurine"
        },
        {
            "Collective noun": "conspiracy"
        },
        {
            "Collective noun": "plot"
        },
        {
            "id": "117",
            "name": "Leopard",
            "Young": "cub",
            "Female": "leopardess",
            "Male": "leopard",
            "Collective noun": "leap",
            "Collateral adjective": "pardine"
        },
        {
            "Collective noun": "lepe"
        },
        {
            "id": "118",
            "name": "Lion",
            "Young": "cub",
            "Female": "lioness",
            "Male": "lion",
            "Collective noun": "pride",
            "Collateral adjective": "leonine"
        },
        {
            "Collective noun": "sawt"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "119",
            "name": "Llama",
            "Young": "cria",
            "Female": "hembra",
            "Male": "macho",
            "Collective noun": "herd",
            "Collateral adjective": "camelid"
        },
        {
            "Collective noun": "flock"
        },
        {
            "id": "120",
            "name": "Lobster",
            "Young": "?",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "pod",
            "Collateral adjective": "homarine"
        },
        {
            "id": "121",
            "name": "Locust",
            "Young": "nymph",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "cloud",
            "Collateral adjective": "caelifera"
        },
        {
            "Collective noun": "host"
        },
        {
            "Collective noun": "plague"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "122",
            "name": "Loris",
            "Young": "infant",
            "Collective noun": "colony",
            "Collateral adjective": "lorisine"
        },
        {
            "id": "123",
            "name": "Louse",
            "Young": "nymph",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "colony",
            "Collateral adjective": "pediculine"
        },
        {
            "id": "124",
            "name": "Lyrebird",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "musket",
            "Collateral adjective": "menurine"
        },
        {
            "id": "125",
            "name": "Magpie",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flock",
            "Collateral adjective": "garruline"
        },
        {
            "Collective noun": "charm"
        },
        {
            "Collective noun": "gulp"
        },
        {
            "Collective noun": "murder"
        },
        {
            "Collective noun": "tiding"
        },
        {
            "Collective noun": "tittering"
        },
        {
            "Collective noun": "tribe"
        },
        {
            "id": "126",
            "name": "Mallard",
            "Young": "duckling",
            "Female": "hen",
            "Male": "greenhead",
            "Collective noun": "flush",
            "Collateral adjective": "anatine",
            "Culinary noun for meat": "poultry"
        },
        {
            "name": "Also see Duck",
            "Collective noun": "lute"
        },
        {
            "Collective noun": "puddling"
        },
        {
            "id": "127",
            "name": "Manatee",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "manatine"
        },
        {
            "Collateral adjective": "sirenian"
        },
        {
            "id": "128",
            "name": "Marten",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "richness",
            "Collateral adjective": "?"
        },
        {
            "id": "129",
            "name": "Meerkat",
            "Young": "pup",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "clan",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "gang"
        },
        {
            "Collective noun": "mob"
        },
        {
            "id": "130",
            "name": "Mink",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "?",
            "Collateral adjective": "musteline"
        },
        {
            "Young": "kit"
        },
        {
            "id": "131",
            "name": "Mole",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "company",
            "Collateral adjective": "talpine"
        },
        {
            "Collective noun": "labour"
        },
        {
            "Collective noun": "movement"
        },
        {
            "id": "132",
            "name": "Monkey",
            "Young": "infant",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "tribe",
            "Collateral adjective": "simian"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "133",
            "name": "Moose",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "cervine",
            "Culinary noun for meat": "venison"
        },
        {
            "id": "134",
            "name": "Mouse",
            "Young": "kitten",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "colony",
            "Collateral adjective": "murine"
        },
        {
            "Young": "pup",
            "Collective noun": "harvest"
        },
        {
            "Collective noun": "horde"
        },
        {
            "Young": "As pet food",
            "Collective noun": "mischief"
        },
        {
            "Young": "pinky/fuzzy/crawler/hopper",
            "Collective noun": "nest"
        },
        {
            "id": "135",
            "name": "Mosquito",
            "Young": "nymph",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "scourge",
            "Collateral adjective": "aedine"
        },
        {
            "Young": "wriggler",
            "Collective noun": "swarm",
            "Collateral adjective": "anopheline"
        },
        {
            "Young": "tumbler",
            "Collective noun": "cloud"
        },
        {
            "id": "136",
            "name": "Mule",
            "Young": "foal",
            "Female": "molly",
            "Male": "john",
            "Collective noun": "barren",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "pack"
        },
        {
            "Collective noun": "span"
        },
        {
            "id": "137",
            "name": "Narwhal",
            "Young": "calf",
            "Female": "-",
            "Male": "-",
            "Collective noun": "blessing",
            "Collateral adjective": "-"
        },
        {
            "id": "138",
            "name": "Newt",
            "Young": "eft",
            "Female": "-",
            "Male": "-",
            "Collective noun": "-",
            "Collateral adjective": "pleurodeline"
        },
        {
            "id": "139",
            "name": "Nightingale",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flock",
            "Collateral adjective": "philomelian"
        },
        {
            "Collective noun": "route"
        },
        {
            "Collective noun": "watch"
        },
        {
            "id": "140",
            "name": "Octopus",
            "Young": "fry",
            "Female": "?",
            "Male": "?",
            "Collective noun": "consortium",
            "Collateral adjective": "octopodine"
        },
        {
            "id": "141",
            "name": "Okapi",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "okapine"
        },
        {
            "id": "142",
            "name": "Opossum",
            "Young": "joey",
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "passel",
            "Collateral adjective": "didelphine"
        },
        {
            "id": "143",
            "name": "Oryx",
            "Young": "calf",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "?"
        },
        {
            "id": "144",
            "name": "Ostrich",
            "Young": "hatchling",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flock",
            "Collateral adjective": "ratite"
        },
        {
            "Young": "chick",
            "Collective noun": "troop",
            "Collateral adjective": "struthious"
        },
        {
            "id": "145",
            "name": "Otter",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "romp",
            "Collateral adjective": "musteline"
        },
        {
            "Young": "whelp",
            "Collective noun": "bevy",
            "Collateral adjective": "lutrine"
        },
        {
            "Collective noun": "family"
        },
        {
            "Collective noun": "raft"
        },
        {
            "id": "146",
            "name": "Owl",
            "Young": "fledgling",
            "Male": "?",
            "Collective noun": "parliament",
            "Collateral adjective": "strigine"
        },
        {
            "Young": "owlet",
            "Collective noun": "stare"
        },
        {
            "id": "147",
            "name": "Ox",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "bovine"
        },
        {
            "Male": "steer",
            "Collective noun": "yoke"
        },
        {
            "Collective noun": "team"
        },
        {
            "Collective noun": "drove"
        },
        {
            "id": "148",
            "name": "Oyster",
            "Young": "spat",
            "Female": "?",
            "Male": "?",
            "Collective noun": "bed",
            "Collateral adjective": "ostracine",
            "Culinary noun for meat": "meat"
        },
        {
            "Collective noun": "cast"
        },
        {
            "Collective noun": "hive"
        },
        {
            "id": "149",
            "name": "Panther",
            "Young": "cub",
            "Female": "pantheress",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "pantherine"
        },
        {
            "id": "150",
            "name": "Parrot",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "company",
            "Collateral adjective": "psittacine"
        },
        {
            "Collective noun": "flock"
        },
        {
            "Collective noun": "pandemonium"
        },
        {
            "id": "151",
            "name": "Partridge",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "bevy",
            "Collateral adjective": "perdicine"
        },
        {
            "Female": "chantelle",
            "Collective noun": "covey"
        },
        {
            "id": "152",
            "name": "Peafowl",
            "Young": "chick",
            "Female": "peahen",
            "Male": "peacock",
            "Collective noun": "party",
            "Collateral adjective": "pavonine",
            "Culinary noun for meat": "poultry"
        },
        {
            "Young": "peachick",
            "Collective noun": "muster"
        },
        {
            "Collective noun": "pride"
        },
        {
            "Collective noun": "ostentation (peacocks)"
        },
        {
            "id": "153",
            "name": "Pelican",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "pod",
            "Collateral adjective": "pelecanine"
        },
        {
            "Young": "nestling"
        },
        {
            "id": "154",
            "name": "Penguin",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "rookery",
            "Collateral adjective": "spheniscine"
        },
        {
            "Young": "nestling",
            "Collective noun": "huddle"
        },
        {
            "Collective noun": "waddle"
        },
        {
            "Collective noun": "(on land) colony"
        },
        {
            "Collective noun": "(in water) raft"
        },
        {
            "id": "155",
            "name": "Pheasant",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "nest",
            "Collateral adjective": "phasianine"
        },
        {
            "Collective noun": "nye"
        },
        {
            "Collective noun": "(brood) nide"
        },
        {
            "Collective noun": "(take-off) bouquet"
        },
        {
            "Collective noun": "(in flight) Guff"
        },
        {
            "id": "156",
            "name": "Pig",
            "Young": "piglet",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "drift",
            "Collateral adjective": "porcine",
            "Culinary noun for meat": "pork"
        },
        {
            "name": "Also see Boar",
            "Young": "farrow",
            "Collective noun": "drove",
            "Collateral adjective": "suilline",
            "Culinary noun for meat": "ham"
        },
        {
            "Young": "shoat/shote (just weaned)",
            "Collective noun": "team (hogs)",
            "Culinary noun for meat": "bacon"
        },
        {
            "Young": "barrow (castrated male)",
            "Collective noun": "passel (hogs)"
        },
        {
            "Young": "gilt (young female that has not given birth)",
            "Collective noun": "parcel (hogs)"
        },
        {
            "Collective noun": "litter (piglets)"
        },
        {
            "id": "157",
            "name": "Pigeon",
            "Young": "squab",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flight",
            "Collateral adjective": "pullastrine",
            "Culinary noun for meat": "squab"
        },
        {
            "Young": "squeaker",
            "Collective noun": "flock"
        },
        {
            "id": "158",
            "name": "Pony- See Horse",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "?"
        },
        {
            "id": "159",
            "name": "Porcupine",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "prickle",
            "Collateral adjective": "hystricine"
        },
        {
            "id": "160",
            "name": "Porpoise",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "crowd",
            "Collateral adjective": "phocoenine"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "pod"
        },
        {
            "Collective noun": "school"
        },
        {
            "Collective noun": "shoal"
        },
        {
            "id": "161",
            "name": "Prairie Dog",
            "Young": "pup",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "coterie",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "town"
        },
        {
            "id": "162",
            "name": "Quail",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "bevy",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "covey"
        },
        {
            "id": "163",
            "name": "Quelea",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "flock",
            "Collateral adjective": "queline"
        },
        {
            "id": "164",
            "name": "Rabbit",
            "Young": "bunny",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "colony",
            "Collateral adjective": "leporine"
        },
        {
            "Young": "kit",
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "bevy"
        },
        {
            "Young": "kitten",
            "Collective noun": "bury"
        },
        {
            "Young": "nestling",
            "Collective noun": "drove"
        },
        {
            "Collective noun": "trace"
        },
        {
            "Collective noun": "leash"
        },
        {
            "Collective noun": "trip"
        },
        {
            "Collective noun": "(domestic) herd"
        },
        {
            "Collective noun": "(hare) down"
        },
        {
            "Collective noun": "husk"
        },
        {
            "Collective noun": "(young) litter"
        },
        {
            "Collective noun": "nest"
        },
        {
            "id": "165",
            "name": "Raccoon",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "nursery",
            "Collateral adjective": "procyonine"
        },
        {
            "Young": "kit",
            "Collective noun": "gaze"
        },
        {
            "id": "166",
            "name": "Rail",
            "Young": "chick",
            "Female": "reeve",
            "Male": "ruff",
            "Collective noun": "?",
            "Collateral adjective": "ralline"
        },
        {
            "id": "167",
            "name": "Ram",
            "Young": "lamb",
            "Female": "ewe",
            "Male": "ram",
            "Collective noun": "flock",
            "Collateral adjective": "arietine",
            "Culinary noun for meat": "lamb"
        },
        {
            "name": "Also see Sheep",
            "Collateral adjective": "ovine",
            "Culinary noun for meat": "mutton"
        },
        {
            "id": "168",
            "name": "Rat",
            "Young": "calf",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "colony",
            "Collateral adjective": "murine"
        },
        {
            "Young": "kitten",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "horde"
        },
        {
            "Young": "nestling",
            "Collective noun": "mischief"
        },
        {
            "Young": "pup",
            "Collective noun": "plague"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "169",
            "name": "Raven",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "unkindness",
            "Collateral adjective": "corvine"
        },
        {
            "id": "170",
            "name": "Red deer",
            "Young": "calf",
            "Female": "hind",
            "Male": "stag",
            "Collective noun": "herd",
            "Collateral adjective": "?",
            "Culinary noun for meat": "venison"
        },
        {
            "id": "171",
            "name": "Red panda",
            "Young": "cub",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "pack",
            "Collateral adjective": "ailuirine"
        },
        {
            "id": "172",
            "name": "Reindeer (caribou)",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "rangiferine"
        },
        {
            "id": "173",
            "name": "Rhinoceros",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "crash",
            "Collateral adjective": "ceratorhine"
        },
        {
            "Collective noun": "herd"
        },
        {
            "id": "174",
            "name": "Rook",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "building",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "clamor"
        },
        {
            "Collective noun": "parliament"
        },
        {
            "id": "175",
            "name": "Ruff",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "hill",
            "Collateral adjective": "?"
        },
        {
            "id": "176",
            "name": "Salamander",
            "Young": "tadpole",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "maelstrom",
            "Collateral adjective": "caudatan"
        },
        {
            "Young": "salamanderling",
            "Collective noun": "band"
        },
        {
            "Collective noun": "congress"
        },
        {
            "id": "177",
            "name": "Salmon",
            "Young": "?",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "run",
            "Collateral adjective": "salmonine"
        },
        {
            "id": "178",
            "name": "Sand Dollar",
            "Young": "larva pluteus (free swimming stage)",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "clypeasteroid"
        },
        {
            "Young": "juvenile (young urchin)"
        },
        {
            "id": "179",
            "name": "Sandpiper",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "fling",
            "Collateral adjective": "scolopacine"
        },
        {
            "id": "180",
            "name": "Sardine",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "family",
            "Collateral adjective": "?"
        },
        {
            "id": "181",
            "name": "Scorpion",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "bed",
            "Collateral adjective": "?"
        },
        {
            "Collective noun": "nest"
        },
        {
            "id": "182",
            "name": "Sea lion",
            "Young": "pup",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "pod",
            "Collateral adjective": "otarine"
        },
        {
            "Young": "calf",
            "Collective noun": "colony"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "rookery"
        },
        {
            "Collective noun": "team"
        },
        {
            "id": "183",
            "name": "Sea Urchin",
            "Young": "larva pluteus (free swimming stage)",
            "Female": "?",
            "Male": "?",
            "Collective noun": "?",
            "Collateral adjective": "?"
        },
        {
            "Young": "juvenile (young urchin)"
        },
        {
            "id": "184",
            "name": "Seahorse",
            "Young": "seafoal",
            "Female": "seamare",
            "Male": "seastallion",
            "Collective noun": "shoal",
            "Collateral adjective": "hippocampal"
        },
        {
            "id": "185",
            "name": "Seal",
            "Young": "pup",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "harem",
            "Collateral adjective": "phocine"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "pod"
        },
        {
            "Collective noun": "rookery"
        },
        {
            "id": "186",
            "name": "Shark",
            "Young": "cub",
            "Female": "?",
            "Male": "bull",
            "Collective noun": "school",
            "Collateral adjective": "selachian",
            "Culinary noun for meat": "flake (AUS)"
        },
        {
            "Young": "pup",
            "Collective noun": "shiver"
        },
        {
            "id": "187",
            "name": "Sheep",
            "Young": "lamb",
            "Female": "ewe",
            "Male": "ram",
            "Collective noun": "down",
            "Collateral adjective": "ovine",
            "Culinary noun for meat": "lamb"
        },
        {
            "name": "Also see Ram",
            "Young": "lambkin",
            "Female": "dam",
            "Male": "buck",
            "Collective noun": "drift",
            "Culinary noun for meat": "mutton"
        },
        {
            "Young": "cosset",
            "Collective noun": "drove",
            "Culinary noun for meat": "hoggett"
        },
        {
            "Collective noun": "mob"
        },
        {
            "Collective noun": "flock"
        },
        {
            "Collective noun": "fold"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "trip"
        },
        {
            "id": "188",
            "name": "Shrew",
            "Young": "shrewlet",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "colony",
            "Collateral adjective": "soricine"
        },
        {
            "Collective noun": "drove"
        },
        {
            "id": "189",
            "name": "Shrimp"
        },
        {
            "id": "190",
            "name": "Skunk",
            "Young": "kit",
            "Female": "sow",
            "Male": "boar",
            "Collective noun": "surfeit",
            "Collateral adjective": "mephitine"
        },
        {
            "id": "191",
            "name": "Snail",
            "Young": "—",
            "Female": "—",
            "Male": "—",
            "Collective noun": "hood",
            "Collateral adjective": "gastropodian",
            "Culinary noun for meat": "escargot"
        },
        {
            "Collective noun": "rout"
        },
        {
            "Collective noun": "walk"
        },
        {
            "id": "192",
            "name": "Snake",
            "Young": "snakelet",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "nest",
            "Collateral adjective": "anguine"
        },
        {
            "Young": "hatchling (a newly hatched snake)",
            "Collective noun": "bed",
            "Collateral adjective": "elapine"
        },
        {
            "Young": "neonate(newborn)",
            "Collective noun": "den",
            "Collateral adjective": "serpentine"
        },
        {
            "Collective noun": "knot",
            "Collateral adjective": "viperine"
        },
        {
            "Collateral adjective": "ophidian"
        },
        {
            "id": "193",
            "name": "Spider",
            "Young": "spiderling",
            "Female": "?",
            "Male": "?",
            "Collective noun": "cluster",
            "Collateral adjective": "arachnine"
        },
        {
            "Collective noun": "clutter",
            "Collateral adjective": "arachnoid"
        },
        {
            "id": "194",
            "name": "Squid",
            "Young": "chick",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "audience",
            "Collateral adjective": "tethidine",
            "Culinary noun for meat": "calamari"
        },
        {
            "id": "195",
            "name": "Squirrel",
            "Young": "pup",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "dray",
            "Collateral adjective": "sciurine"
        },
        {
            "Young": "kit",
            "Collective noun": "scurry"
        },
        {
            "Young": "kitten"
        },
        {
            "id": "196",
            "name": "Starling",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "chattering",
            "Collateral adjective": "sturnine"
        },
        {
            "Collective noun": "murmuration"
        },
        {
            "id": "197",
            "name": "Stingray",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "fever",
            "Collateral adjective": "myliobatoid"
        },
        {
            "id": "198",
            "name": "Stinkbug",
            "Young": "nymph",
            "Female": "?",
            "Male": "?",
            "Collective noun": "intrusion",
            "Collateral adjective": "pentatomidae"
        },
        {
            "id": "199",
            "name": "Stork",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "muster",
            "Collateral adjective": "ciconine"
        },
        {
            "Collective noun": "mustering"
        },
        {
            "id": "200",
            "name": "Swallow",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "flight",
            "Collateral adjective": "hirundinine"
        },
        {
            "Collective noun": "gulp"
        },
        {
            "id": "201",
            "name": "Swan",
            "Young": "cygnet",
            "Female": "pen",
            "Male": "cob",
            "Collective noun": "bank",
            "Collateral adjective": "cygnine"
        },
        {
            "Young": "flapper",
            "Collective noun": "bevy"
        },
        {
            "Collective noun": "flock"
        },
        {
            "Collective noun": "game"
        },
        {
            "Collective noun": "herd"
        },
        {
            "Collective noun": "team"
        },
        {
            "Collective noun": "In flight"
        },
        {
            "Collective noun": "flight"
        },
        {
            "Collective noun": "wedge"
        },
        {
            "id": "202",
            "name": "Tapir",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "tapirine"
        },
        {
            "Collective noun": "measure"
        },
        {
            "id": "203",
            "name": "Tarsier",
            "Young": "infant",
            "Female": "doe",
            "Male": "buck",
            "Collective noun": "herd",
            "Collateral adjective": "tarsiine"
        },
        {
            "Collective noun": "plot"
        },
        {
            "Collective noun": "troop"
        },
        {
            "id": "204",
            "name": "Termite",
            "Young": "larva",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "brood",
            "Collateral adjective": "isopteran"
        },
        {
            "Collective noun": "colony"
        },
        {
            "Collective noun": "nest"
        },
        {
            "Collective noun": "swarm"
        },
        {
            "id": "205",
            "name": "Tiger",
            "Young": "cub",
            "Female": "tigress",
            "Male": "tiger",
            "Collective noun": "ambush",
            "Collateral adjective": "tigrine"
        },
        {
            "Young": "whelp",
            "Collective noun": "streak"
        },
        {
            "id": "206",
            "name": "Toad",
            "Young": "tadpole",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "knot",
            "Collateral adjective": "ranine"
        },
        {
            "Young": "toadlet",
            "Collective noun": "nest",
            "Collateral adjective": "batrachian"
        },
        {
            "Collective noun": "lump}"
        },
        {
            "id": "207",
            "name": "Trout",
            "Young": "fingerling",
            "Female": "hen",
            "Male": "cock",
            "Collective noun": "hover",
            "Collateral adjective": "?"
        },
        {
            "id": "208",
            "name": "Turkey",
            "Young": "poult",
            "Female": "hen",
            "Male": "tom",
            "Collective noun": "rafter",
            "Collateral adjective": "?",
            "Culinary noun for meat": "poultry"
        },
        {
            "Male": "gobbler",
            "Collective noun": "gang"
        },
        {
            "Male": "stag",
            "Collective noun": "posse"
        },
        {
            "Male": "jake (immature)"
        },
        {
            "id": "209",
            "name": "Turtle",
            "Young": "hatchling",
            "Female": "N/A",
            "Male": "N/A",
            "Collective noun": "bale",
            "Collateral adjective": "chelonian"
        },
        {
            "Collective noun": "dule"
        },
        {
            "Collective noun": "nest"
        },
        {
            "Collective noun": "turn"
        },
        {
            "id": "210",
            "name": "Vicuña",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "posse",
            "Collateral adjective": "cameline"
        },
        {
            "Collective noun": "herd"
        },
        {
            "id": "211",
            "name": "Viper",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "generation",
            "Collateral adjective": "viperine"
        },
        {
            "Collective noun": "nest"
        },
        {
            "id": "212",
            "name": "Vulture",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "venue",
            "Collateral adjective": "?"
        },
        {
            "id": "213",
            "name": "Wallaby",
            "Young": "joey",
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "mob",
            "Collateral adjective": "?"
        },
        {
            "id": "214",
            "name": "Walrus",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "odobenine"
        },
        {
            "Collective noun": "flock"
        },
        {
            "Collective noun": "pod"
        },
        {
            "Collective noun": "wealth"
        },
        {
            "id": "215",
            "name": "Wasp",
            "Young": "larva",
            "Female": "queen",
            "Male": "drone",
            "Collective noun": "swarm",
            "Collateral adjective": "vespine"
        },
        {
            "Female": "worker",
            "Collective noun": "hive"
        },
        {
            "Collective noun": "colony"
        },
        {
            "Collective noun": "nest"
        },
        {
            "id": "216",
            "name": "Water buffalo",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "pot",
            "Culinary noun for meat": "carabeef"
        },
        {
            "id": "217",
            "name": "Weasel",
            "Young": "pup",
            "Female": "bitch",
            "Male": "buck",
            "Collective noun": "gang",
            "Collateral adjective": "musteline"
        },
        {
            "Young": "kit",
            "Female": "doe",
            "Male": "dog",
            "Collective noun": "sneak"
        },
        {
            "Female": "jill",
            "Male": "hub"
        },
        {
            "Male": "jack"
        },
        {
            "id": "218",
            "name": "Whale",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "gam",
            "Collateral adjective": "cetacean",
            "Culinary noun for meat": "blubber"
        },
        {
            "Collective noun": "herd",
            "Collateral adjective": "cetaceous"
        },
        {
            "Collective noun": "mob"
        },
        {
            "Collective noun": "pod"
        },
        {
            "Collective noun": "school"
        },
        {
            "id": "219",
            "name": "Wolf",
            "Young": "cub",
            "Female": "bitch",
            "Male": "dog",
            "Collective noun": "pack",
            "Collateral adjective": "lupine"
        },
        {
            "Young": "pup",
            "Female": "she-wolf",
            "Collective noun": "route"
        },
        {
            "Young": "whelp"
        },
        {
            "id": "220",
            "name": "Wolverine",
            "Young": "kit",
            "Female": "angeline",
            "Male": "wolverine",
            "Collective noun": "pack",
            "Collateral adjective": "musteline"
        },
        {
            "Young": "whelp",
            "Collective noun": "gang"
        },
        {
            "Collective noun": "mob"
        },
        {
            "id": "221",
            "name": "Wombat",
            "Young": "joey",
            "Female": "jill",
            "Male": "jack",
            "Collective noun": "mob",
            "Collateral adjective": "?"
        },
        {
            "id": "222",
            "name": "Woodcock",
            "Young": "?",
            "Female": "?",
            "Male": "?",
            "Collective noun": "fall",
            "Collateral adjective": "?"
        },
        {
            "id": "223",
            "name": "Woodpecker",
            "Young": "chick",
            "Female": "?",
            "Male": "?",
            "Collective noun": "descent",
            "Collateral adjective": "picine"
        },
        {
            "id": "224",
            "name": "Worm",
            "Young": "wormlet",
            "Female": "?",
            "Male": "?",
            "Collective noun": "bed",
            "Collateral adjective": "helminthic"
        },
        {
            "Collective noun": "clat",
            "Collateral adjective": "vermian"
        },
        {
            "Collective noun": "clew"
        },
        {
            "id": "225",
            "name": "Wren",
            "Young": "chick",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "troglodytine"
        },
        {
            "Collective noun": "cabinet"
        },
        {
            "id": "226",
            "name": "Yak",
            "Young": "calf",
            "Female": "cow",
            "Male": "bull",
            "Collective noun": "herd",
            "Collateral adjective": "?"
        },
        {
            "id": "227",
            "name": "Zebra",
            "Young": "colt",
            "Female": "mare",
            "Male": "stallion",
            "Collective noun": "herd",
            "Collateral adjective": "zebrine"
        },

];
var animal = jQuery.grep(animal, function (n, i) {
    return (n.id !== null && n.id !== undefined);
});

var bird = [
        {
            "id": "1",
            "description": "कबूतर (Kabootar)",
            "name": "Pigeon"
        },
        {
            "id": "2",
            "description": "उल्लू (Ullu)",
            "name": "Owl"
        },
        {
            "id": "3",
            "description": "मुर्गा (Murga)",
            "name": "Cock"
        },
        {
            "id": "4",
            "description": "हंस (Hans)",
            "name": "Swan"
        },
        {
            "id": "5",
            "description": "कोयल (Koyal)",
            "name": "Cuckoo"
        },
        {
            "id": "6",
            "description": "बुलबुल (Bulbul)",
            "name": "Nightingale"
        },
        {
            "id": "7",
            "description": "तोता (Tota)",
            "name": "Parrot"
        },
        {
            "id": "8",
            "description": "मोर (Mor)",
            "name": "Peacock"
        },
        {
            "id": "9",
            "description": "बतख (Batakh)",
            "name": "Duck"
        },
        {
            "id": "10",
            "description": "मुर्गी (Murgi)",
            "name": "Hen"
        },
        {
            "id": "11",
            "description": "बाज (Baj)",
            "name": "Hawk / Falcon"
        },
        {
            "id": "12",
            "description": "चील (Cheel)",
            "name": "Eagle"
        },
        {
            "id": "13",
            "description": "कौआ (Kaua)",
            "name": "Crow"
        },
        {
            "id": "14",
            "description": "चिड़िया (Chidiya)",
            "name": "Bird"
        },
        {
            "id": "15",
            "description": "चमगादड़ (Chamgadad)",
            "name": "Bat"
        },
        {
            "id": "16",
            "description": "गौरेया (Gaureya)",
            "name": "Sparrow"
        },
        {
            "id": "17",
            "description": "गिद्ध (Gidd)",
            "name": "Vulture"
        },
        {
            "id": "18",
            "description": "शुतुरमुर्ग (Shuturmurg)",
            "name": "Ostrich"
        },
        {
            "id": "19",
            "description": "फाख्ता (Fakhta)",
            "name": "Dove"
        },
        {
            "id": "20",
            "description": "सारस (Saras)",
            "name": "Crane"
        },
        {
            "id": "21",
            "description": "मैना (Maina)",
            "name": "Mynah"
        },
        {
            "id": "22",
            "description": "चकता (Chakta)",
            "name": "Skylark"
        },
        {
            "id": "23",
            "description": "कठफोड़वा (Kathfodva)",
            "name": "Woodpecker"
        },
        {
            "id": "24",
            "description": "राम चिरैया (Ramchiraiya)",
            "name": "Kingfisher"
        },
        {
            "id": "25",
            "description": "तीतर (Titar)",
            "name": "Partridge"
        },
        {
            "id": "26",
            "description": "वगुला (Vagula)",
            "name": "Stork"
        },
        {
            "id": "27",
            "description": "बटेर (Bater)",
            "name": "Quail"
        },
        {
            "id": "28",
            "description": "बया (Baya)",
            "name": "Weaver"
        }
];

var body_parts =  [
        {
            "id": "1",
            "description": "आँख (Aankh)",
            "name": "Eye"
        },
        {
            "id": "2",
            "description": "कान (Kan)",
            "name": "Ear"
        },
        {
            "id": "3",
            "description": "नाक (Nak)",
            "name": "Nose"
        },
        {
            "id": "4",
            "description": "हाथ (Hath)",
            "name": "Hand"
        },
        {
            "id": "5",
            "description": "पैर (Pair)",
            "name": "Leg, Foot"
        },
        {
            "id": "6",
            "description": "सिर (Sir)",
            "name": "Head"
        },
        {
            "id": "7",
            "description": "बाल (Bal)",
            "name": "Hair"
        },
        {
            "id": "8",
            "description": "माथा (Matha)",
            "name": "Forehead"
        },
        {
            "id": "9",
            "description": "गला (Gala)",
            "name": "Throat"
        },
        {
            "id": "10",
            "description": "कंधा (Kandha)",
            "name": "Shoulder"
        },
        {
            "id": "11",
            "description": "कोहनी (Kohni)",
            "name": "Elbow"
        },
        {
            "id": "12",
            "description": "होठ (Hoth)",
            "name": "Lip"
        },
        {
            "id": "13",
            "description": "जीभ (Jibh)",
            "name": "Tongue"
        },
        {
            "id": "14",
            "description": "दाँत (Dant)",
            "name": "Teeth"
        },
        {
            "id": "15",
            "description": "गाल (Gaal)",
            "name": "Cheek"
        },
        {
            "id": "16",
            "description": "पलक (Palak)",
            "name": "Eyelid"
        },
        {
            "id": "17",
            "description": "भौंह (Bhaunh)",
            "name": "Eyebrow"
        },
        {
            "id": "18",
            "description": "कलाई (Kalai)",
            "name": "Wrist"
        },
        {
            "id": "19",
            "description": "हथेली (Hatheli)",
            "name": "Palm"
        },
        {
            "id": "20",
            "description": "अंगुली (Anguli)",
            "name": "Finger"
        },
        {
            "id": "21",
            "description": "नाखून (Nakhoon)",
            "name": "Nail"
        },
        {
            "id": "22",
            "description": "पेट (Pet)",
            "name": "Stomach, Belly"
        },
        {
            "id": "23",
            "description": "पीठ (Peeth)",
            "name": "Back"
        },
        {
            "id": "24",
            "description": "छाती (Chati)",
            "name": "Chest"
        },
        {
            "id": "25",
            "description": "कमर (Kamar)",
            "name": "Waist"
        },
        {
            "id": "26",
            "description": "नाभि (Nabhi)",
            "name": "Navel"
        },
        {
            "id": "27",
            "description": "जांघ (Jangh)",
            "name": "Thigh"
        },
        {
            "id": "28",
            "description": "घुटना (Ghutana)",
            "name": "Knee"
        },
        {
            "id": "29",
            "description": "पिंडली (Pindli)",
            "name": "Calf"
        },
        {
            "id": "30",
            "description": "टखना (Takhana)",
            "name": "Ankle"
        },
        {
            "id": "31",
            "description": "पैर का अगूँठा (Pair ka Angutha)",
            "name": "Toe"
        },
        {
            "id": "32",
            "description": "नस (Nas)",
            "name": "Nerve"
        },
        {
            "id": "33",
            "description": "खून, रक्त (Khoon, Rakt)",
            "name": "Blood"
        },
        {
            "id": "34",
            "description": "हड्डी (Haddi)",
            "name": "Bone"
        },
        {
            "id": "35",
            "description": "दाढ़ी (Dadi)",
            "name": "Beard"
        },
        {
            "id": "36",
            "description": "चेहरा (Chehara)",
            "name": "Face"
        },
        {
            "id": "37",
            "description": "भुजा (Bhuja)",
            "name": "Arm"
        },
        {
            "id": "38",
            "description": "हाथ का अँगूठा (Hath ka Angutha)",
            "name": "Thumb"
        },
        {
            "id": "39",
            "description": "गरदन (Gardan)",
            "name": "Neck"
        },
        {
            "id": "40",
            "description": "रीढ़ की हड्डी (Ridh ki Haddi)",
            "name": "Spine"
        },
        {
            "id": "41",
            "description": "शरीर (Sharir)",
            "name": "Body"
        },
        {
            "id": "42",
            "description": "खोपड़ी (Khopadhi)",
            "name": "Skull"
        },
        {
            "id": "43",
            "description": "जोड़ (Jod)",
            "name": "Joint"
        },
        {
            "id": "44",
            "description": "मुट्ठी (Mutthi)",
            "name": "Fist"
        },
        {
            "id": "45",
            "description": "पुतली (Putali)",
            "name": "Pupil"
        },
        {
            "id": "46",
            "description": "थोहडी (Thohadi)",
            "name": "Chin"
        },
        {
            "id": "47",
            "description": "पैर का पंजा (Pair ka Panja)",
            "name": "Paw"
        },
        {
            "id": "48",
            "description": "एडी (Eadi)",
            "name": "Heel"
        },
        {
            "id": "49",
            "description": "कूल्हा (Koolha)",
            "name": "Hip"
        },
        {
            "id": "50",
            "description": "माँसपेशी (Manspeshi)",
            "name": "Muscles"
        },
        {
            "id": "51",
            "description": "फेफड़ा (Fefada)",
            "name": "Lung"
        },
        {
            "id": "52",
            "description": "पसली (Pasali)",
            "name": "Rib"
        },
        {
            "id": "53",
            "description": "नथुना (Nathuna)",
            "name": "Nostril"
        },
        {
            "id": "54",
            "description": "जिगर (Jigar)",
            "name": "Liver"
        },
        {
            "id": "55",
            "description": "जबड़ा (Jabda)",
            "name": "Jaw"
        },
        {
            "id": "56",
            "description": "गुरदा (Gurda)",
            "name": "Kidney"
        },
        {
            "id": "57",
            "description": "कनपटी (Kanpati)",
            "name": "Temple"
        },
        {
            "id": "58",
            "description": "हृदय, दिल (Hriday, Dil)",
            "name": "Heart"
        },
        {
            "id": "59",
            "description": "दिमाग (dimag)",
            "name": "Brain"
        },
        {
            "id": "60",
            "description": "त्वचा (Tvacha)",
            "name": "Skin"
        },
        {
            "id": "61",
            "description": "मूँछ (Moonchh)",
            "name": "Moustache"
        },
        {
            "id": "62",
            "description": "स्तन (Stan)",
            "name": "Breast"
        },
        {
            "id": "63",
            "description": "बगल (Bagal)",
            "name": "Armpit"
        },
        {
            "id": "64",
            "description": "कंठ (Kanth)",
            "name": "Larynx"
        }
];

var color =  [
        {
            "id": "1",
            "description": "काला (Kala)",
            "name": "Black"
        },
        {
            "id": "2",
            "description": "सफेद (Safed)",
            "name": "White"
        },
        {
            "id": "3",
            "description": "नीला (Neela)",
            "name": "Blue"
        },
        {
            "id": "4",
            "description": "पीला (Peela)",
            "name": "Yellow"
        },
        {
            "id": "5",
            "description": "हरा (Hara)",
            "name": "Green"
        },
        {
            "id": "6",
            "description": "गुलाबी (Gulabi)",
            "name": "Pink"
        },
        {
            "id": "7",
            "description": "बादामी, भूरा (Badami /Bhura)",
            "name": "Brown"
        },
        {
            "id": "8",
            "description": "नारंगी (Narangi)",
            "name": "Orange"
        },
        {
            "id": "9",
            "description": "आसमानी (Asamani)",
            "name": "Sky Blue"
        },
        {
            "id": "10",
            "description": "स्लेटी (Sleti)",
            "name": "Gray"
        },
        {
            "id": "11",
            "description": "लाल (Lal)",
            "name": "Red"
        },
        {
            "id": "12",
            "description": "बैगनी (Baigni)",
            "name": "Purple, Violet"
        },
        {
            "id": "13",
            "description": "गहरा नीला (Gahara Neela)",
            "name": "Navy Blue"
        },
        {
            "id": "14",
            "description": "सुनहरा (Sunhara)",
            "name": "Golden"
        },
        {
            "id": "15",
            "description": "चांदी (Chandi)",
            "name": "Silver"
        },
        {
            "id": "16",
            "description": "चमकीला (Chamkeela)",
            "name": "Bright"
        },
        {
            "id": "17",
            "description": "मैरुन (Maroon)",
            "name": "Brownish Crimson"
        },
        {
            "id": "18",
            "description": "खाकी (Khaki)",
            "name": "Khaki"
        },
        {
            "id": "19",
            "description": "कत्थई (Katthai)"
        }
];

var country = [
        {
            "id": "1",
            "name": "Zimbabwe"
        },
        {
            "id": "2",
            "name": "Zambia"
        },
        {
            "id": "3",
            "name": "Yemen"
        },
        {
            "id": "4",
            "name": "Vietnam"
        },
        {
            "id": "5",
            "name": "Venezuela"
        },
        {
            "id": "6",
            "name": "Vatican City"
        },
        {
            "id": "7",
            "name": "Vanuatu"
        },
        {
            "id": "8",
            "name": "Uzbekistan"
        },
        {
            "id": "9",
            "name": "Uruguay"
        },
        {
            "id": "10",
            "name": "United States"
        },
        {
            "id": "11",
            "name": "United Kingdom"
        },
        {
            "id": "12",
            "name": "United Arab Emirates"
        },
        {
            "id": "13",
            "name": "Ukraine"
        },
        {
            "id": "14",
            "name": "Uganda"
        },
        {
            "id": "15",
            "name": "Tuvalu"
        },
        {
            "id": "16",
            "name": "Turkmenistan"
        },
        {
            "id": "17",
            "name": "Turkey"
        },
        {
            "id": "18",
            "name": "Tunisia"
        },
        {
            "id": "19",
            "name": "Trinidad and Tobago"
        },
        {
            "id": "20",
            "name": "Tonga"
        },
        {
            "id": "21",
            "name": "Togo"
        },
        {
            "id": "22",
            "name": "Timor-Leste / East Timor"
        },
        {
            "id": "23",
            "name": "Thailand"
        },
        {
            "id": "24",
            "name": "Tanzania"
        },
        {
            "id": "25",
            "name": "Tajikistan"
        },
        {
            "id": "26",
            "name": "Taiwan"
        },
        {
            "id": "27",
            "name": "SÃ£o TomÃ© and PrÃ­ncipe"
        },
        {
            "id": "28",
            "name": "Syria"
        },
        {
            "id": "29",
            "name": "Switzerland"
        },
        {
            "id": "30",
            "name": "Sweden"
        },
        {
            "id": "31",
            "name": "Swaziland"
        },
        {
            "id": "32",
            "name": "Suriname"
        },
        {
            "id": "33",
            "name": "Sudan"
        },
        {
            "id": "34",
            "name": "Sri Lanka"
        },
        {
            "id": "35",
            "name": "Spain"
        },
        {
            "id": "36",
            "name": "South Ossetia"
        },
        {
            "id": "37",
            "name": "South Africa"
        },
        {
            "id": "38",
            "name": "Somaliland"
        },
        {
            "id": "39",
            "name": "Somalia"
        },
        {
            "id": "40",
            "name": "Solomon Islands"
        },
        {
            "id": "41",
            "name": "Slovenia"
        },
        {
            "id": "42",
            "name": "Slovakia"
        },
        {
            "id": "43",
            "name": "Singapore"
        },
        {
            "id": "44",
            "name": "Sierra Leone"
        },
        {
            "id": "45",
            "name": "Seychelles"
        },
        {
            "id": "46",
            "name": "Serbia"
        },
        {
            "id": "47",
            "name": "Senegal"
        },
        {
            "id": "48",
            "name": "Saudi Arabia"
        },
        {
            "id": "49",
            "name": "San Marino"
        },
        {
            "id": "50",
            "name": "Samoa"
        },
        {
            "id": "51",
            "name": "Saint Vincent and the Grenadines"
        },
        {
            "id": "52",
            "name": "Saint Lucia"
        },
        {
            "id": "53",
            "name": "Saint Kitts and Nevis"
        },
        {
            "id": "54",
            "name": "Sahrawi Arab Democratic Republic"
        },
        {
            "id": "55",
            "name": "Rwanda"
        },
        {
            "id": "56",
            "name": "Russia"
        },
        {
            "id": "57",
            "name": "Romania"
        },
        {
            "id": "58",
            "name": "Qatar"
        },
        {
            "id": "59",
            "name": "Portugal"
        },
        {
            "id": "60",
            "name": "Poland"
        },
        {
            "id": "61",
            "name": "Philippines"
        },
        {
            "id": "62",
            "name": "Peru"
        },
        {
            "id": "63",
            "name": "Paraguay"
        },
        {
            "id": "64",
            "name": "Papua New Guinea"
        },
        {
            "id": "65",
            "name": "Panama"
        },
        {
            "id": "66",
            "name": "Palestine"
        },
        {
            "id": "67",
            "name": "Palau"
        },
        {
            "id": "68",
            "name": "Pakistan"
        },
        {
            "id": "69",
            "name": "Oman"
        },
        {
            "id": "70",
            "name": "Norway"
        },
        {
            "id": "71",
            "name": "Northern Cyprus"
        },
        {
            "id": "72",
            "name": "Niue"
        },
        {
            "id": "73",
            "name": "Nigeria"
        },
        {
            "id": "74",
            "name": "Niger"
        },
        {
            "id": "75",
            "name": "Nicaragua"
        },
        {
            "id": "76",
            "name": "New Zealand"
        },
        {
            "id": "77",
            "name": "Netherlands"
        },
        {
            "id": "78",
            "name": "Nepal"
        },
        {
            "id": "79",
            "name": "Nauru"
        },
        {
            "id": "80",
            "name": "Namibia"
        },
        {
            "id": "81",
            "name": "Nagorno-Karabakh"
        },
        {
            "id": "82",
            "name": "Myanmar / Burma"
        },
        {
            "id": "83",
            "name": "Mozambique"
        },
        {
            "id": "84",
            "name": "Morocco"
        },
        {
            "id": "85",
            "name": "Montenegro"
        },
        {
            "id": "86",
            "name": "Mongolia"
        },
        {
            "id": "87",
            "name": "Monaco"
        },
        {
            "id": "88",
            "name": "Moldova"
        },
        {
            "id": "89",
            "name": "Micronesia"
        },
        {
            "id": "90",
            "name": "Mexico"
        },
        {
            "id": "91",
            "name": "Mauritius"
        },
        {
            "id": "92",
            "name": "Mauritania"
        },
        {
            "id": "93",
            "name": "Marshall Islands"
        },
        {
            "id": "94",
            "name": "Malta"
        },
        {
            "id": "95",
            "name": "Mali"
        },
        {
            "id": "96",
            "name": "Maldives"
        },
        {
            "id": "97",
            "name": "Malaysia"
        },
        {
            "id": "98",
            "name": "Malawi"
        },
        {
            "id": "99",
            "name": "Madagascar"
        },
        {
            "id": "100",
            "name": "Macedonia"
        },
        {
            "id": "101",
            "name": "Luxembourg"
        },
        {
            "id": "102",
            "name": "Lithuania"
        },
        {
            "id": "103",
            "name": "Liechtenstein"
        },
        {
            "id": "104",
            "name": "Libya"
        },
        {
            "id": "105",
            "name": "Liberia"
        },
        {
            "id": "106",
            "name": "Lesotho"
        },
        {
            "id": "107",
            "name": "Lebanon"
        },
        {
            "id": "108",
            "name": "Latvia"
        },
        {
            "id": "109",
            "name": "Laos"
        },
        {
            "id": "110",
            "name": "Kyrgyzstan"
        },
        {
            "id": "111",
            "name": "Kuwait"
        },
        {
            "id": "112",
            "name": "Kosovo"
        },
        {
            "id": "113",
            "name": "Korea, South"
        },
        {
            "id": "114",
            "name": "Korea, North"
        },
        {
            "id": "115",
            "name": "Kiribati"
        },
        {
            "id": "116",
            "name": "Kenya"
        },
        {
            "id": "117",
            "name": "Kazakhstan"
        },
        {
            "id": "118",
            "name": "Jordan"
        },
        {
            "id": "119",
            "name": "Japan"
        },
        {
            "id": "120",
            "name": "Jamaica"
        },
        {
            "id": "121",
            "name": "Ivory Coast"
        },
        {
            "id": "122",
            "name": "Italy"
        },
        {
            "id": "123",
            "name": "Israel"
        },
        {
            "id": "124",
            "name": "Ireland"
        },
        {
            "id": "125",
            "name": "Iraq"
        },
        {
            "id": "126",
            "name": "Iran"
        },
        {
            "id": "127",
            "name": "Indonesia"
        },
        {
            "id": "128",
            "name": "India"
        },
        {
            "id": "129",
            "name": "Iceland"
        },
        {
            "id": "130",
            "name": "Hungary"
        },
        {
            "id": "131",
            "name": "Honduras"
        },
        {
            "id": "132",
            "name": "Haiti"
        },
        {
            "id": "133",
            "name": "Guyana"
        },
        {
            "id": "134",
            "name": "Guinea-Bissau"
        },
        {
            "id": "135",
            "name": "Guinea"
        },
        {
            "id": "136",
            "name": "Guatemala"
        },
        {
            "id": "137",
            "name": "Grenada"
        },
        {
            "id": "138",
            "name": "Greece"
        },
        {
            "id": "139",
            "name": "Ghana"
        },
        {
            "id": "140",
            "name": "Germany"
        },
        {
            "id": "141",
            "name": "Georgia"
        },
        {
            "id": "142",
            "name": "Gambia"
        },
        {
            "id": "143",
            "name": "Gabon"
        },
        {
            "id": "144",
            "name": "France"
        },
        {
            "id": "145",
            "name": "Finland"
        },
        {
            "id": "146",
            "name": "Fiji"
        },
        {
            "id": "147",
            "name": "Ethiopia"
        },
        {
            "id": "148",
            "name": "Estonia"
        },
        {
            "id": "149",
            "name": "Eritrea"
        },
        {
            "id": "150",
            "name": "Equatorial Guinea"
        },
        {
            "id": "151",
            "name": "El Salvador"
        },
        {
            "id": "152",
            "name": "Egypt"
        },
        {
            "id": "153",
            "name": "Ecuador"
        },
        {
            "id": "154",
            "name": "East Timor"
        },
        {
            "id": "155",
            "name": "Dominican Republic"
        },
        {
            "id": "156",
            "name": "Dominica"
        },
        {
            "id": "157",
            "name": "Djibouti"
        },
        {
            "id": "158",
            "name": "Denmark"
        },
        {
            "id": "159",
            "name": "CÃ´te d'Ivoire"
        },
        {
            "id": "160",
            "name": "Czech Republic"
        },
        {
            "id": "161",
            "name": "Cyprus"
        },
        {
            "id": "162",
            "name": "Cuba"
        },
        {
            "id": "163",
            "name": "Croatia"
        },
        {
            "id": "164",
            "name": "Costa Rica"
        },
        {
            "id": "165",
            "name": "Cook Islands"
        },
        {
            "id": "166",
            "name": "Congo"
        },
        {
            "id": "167",
            "name": "Comoros"
        },
        {
            "id": "168",
            "name": "Colombia"
        },
        {
            "id": "169",
            "name": "China"
        },
        {
            "id": "170",
            "name": "Chile"
        },
        {
            "id": "171",
            "name": "Chad"
        },
        {
            "id": "172",
            "name": "Central African Republic"
        },
        {
            "id": "173",
            "name": "Cape Verde"
        },
        {
            "id": "174",
            "name": "Canada"
        },
        {
            "id": "175",
            "name": "Cameroon"
        },
        {
            "id": "176",
            "name": "Cambodia"
        },
        {
            "id": "177",
            "name": "Burundi"
        },
        {
            "id": "178",
            "name": "Burma"
        },
        {
            "id": "179",
            "name": "Burkina Faso"
        },
        {
            "id": "180",
            "name": "Bulgaria"
        },
        {
            "id": "181",
            "name": "Brunei"
        },
        {
            "id": "182",
            "name": "Brazil"
        },
        {
            "id": "183",
            "name": "Botswana"
        },
        {
            "id": "184",
            "name": "Bosnia and Herzegovina"
        },
        {
            "id": "185",
            "name": "Bolivia"
        },
        {
            "id": "186",
            "name": "Bhutan"
        },
        {
            "id": "187",
            "name": "Benin"
        },
        {
            "id": "188",
            "name": "Belize"
        },
        {
            "id": "189",
            "name": "Belgium"
        },
        {
            "id": "190",
            "name": "Belarus"
        },
        {
            "id": "191",
            "name": "Barbados"
        },
        {
            "id": "192",
            "name": "Bangladesh"
        },
        {
            "id": "193",
            "name": "Bahrain"
        },
        {
            "id": "194",
            "name": "Bahamas"
        },
        {
            "id": "195",
            "name": "Azerbaijan"
        },
        {
            "id": "196",
            "name": "Austria"
        },
        {
            "id": "197",
            "name": "Australia"
        },
        {
            "id": "198",
            "name": "Armenia"
        },
        {
            "id": "199",
            "name": "Argentina"
        },
        {
            "id": "200",
            "name": "Antigua and Barbuda"
        },
        {
            "id": "201",
            "name": "Angola"
        },
        {
            "id": "202",
            "name": "Andorra"
        },
        {
            "id": "203",
            "name": "Algeria"
        },
        {
            "id": "204",
            "name": "Albania"
        },
        {
            "id": "205",
            "name": "Afghanistan"
        },
        {
            "id": "206",
            "name": "Abkhazia"
        }
];

var family_member =  [
        {
            "id": "1",
            "description": "दादाजी (Dadaji)",
            "name": "Grandfather"
        },
        {
            "id": "2",
            "description": "दादीजी (Dadiji)",
            "name": "Grandmother"
        },
        {
            "id": "3",
            "description": "माता (Mata)",
            "name": "Mother"
        },
        {
            "id": "4",
            "description": "पिता (Pita)",
            "name": "Father"
        },
        {
            "id": "5",
            "description": "भाई (Bhai)",
            "name": "Brother"
        },
        {
            "id": "6",
            "description": "बहिन (Bahin)",
            "name": "Sister"
        },
        {
            "id": "7",
            "description": "चाचा (Chacha)",
            "name": "Uncle"
        },
        {
            "id": "8",
            "description": "चाची (Chachi)",
            "name": "Aunty"
        },
        {
            "id": "9",
            "description": "पुत्र, बेटा (Putra)",
            "name": "Son"
        },
        {
            "id": "10",
            "description": "पुत्री, बेटी (Putri)",
            "name": "Daughter"
        },
        {
            "id": "11",
            "description": "पोता, नाती (Nati)",
            "name": "Grandson"
        },
        {
            "id": "12",
            "description": "पोती, नातिन (Natin)",
            "name": "Granddaughter"
        },
        {
            "id": "13",
            "description": "भतीजा (Bhatija)",
            "name": "Nephew"
        },
        {
            "id": "14",
            "description": "भतीजी (Bhatiji)",
            "name": "Niece"
        },
        {
            "id": "15",
            "description": "भांजा (Bhanja)",
            "name": "Nephew"
        },
        {
            "id": "16",
            "description": "भांजी (Bhanji)",
            "name": "Niece"
        },
        {
            "id": "17",
            "description": "बुआ (Bua)",
            "name": "Aunty"
        },
        {
            "id": "18",
            "description": "फूफा (Fufa)",
            "name": "Uncle"
        },
        {
            "id": "19",
            "description": "मामा (Mama)",
            "name": "Maternal Uncle"
        },
        {
            "id": "20",
            "description": "मामी (Mami)",
            "name": "Maternal Aunt"
        },
        {
            "id": "21",
            "description": "मौसी (Mausi)",
            "name": "Aunty"
        },
        {
            "id": "22",
            "description": "मौसा (Mausa)",
            "name": "Uncle"
        },
        {
            "id": "23",
            "description": "सास (Sas)",
            "name": "Mother in law"
        },
        {
            "id": "24",
            "description": "ससुर (Shwsur)",
            "name": "Father in law"
        },
        {
            "id": "25",
            "description": "साला (Sala)",
            "name": "Brother in law"
        },
        {
            "id": "26",
            "description": "साली (Sali)",
            "name": "Sister in law"
        },
        {
            "id": "27",
            "description": "नन्द (Nand)",
            "name": "Sister in law"
        },
        {
            "id": "28",
            "description": "देवर (Devar)",
            "name": "Brother in law"
        },
        {
            "id": "29",
            "description": "भाभी (Bhabhi)",
            "name": "Sister in law"
        },
        {
            "id": "30",
            "description": "पति (Pati)",
            "name": "Husband"
        },
        {
            "id": "31",
            "description": "पत्नी (Patni)",
            "name": "Wife"
        },
        {
            "id": "32",
            "description": "जीजाजी (Jijaji)",
            "name": "Brother in law"
        },
        {
            "id": "33",
            "description": "दामाद (Damad)",
            "name": "Son In Law"
        },
        {
            "id": "34",
            "description": "ताई (Tai)",
            "name": "Aunty"
        },
        {
            "id": "35",
            "description": "ताऊ (Tau)",
            "name": "Uncle"
        },
        {
            "id": "36",
            "description": "पुत्र वधू, बहु (Putra Vadhu)",
            "name": "Daughter In Law"
        },
        {
            "id": "37",
            "description": "नाना (Nana)",
            "name": "Grandfather"
        },
        {
            "id": "38",
            "description": "नानी (Nani)",
            "name": "Grandmother"
        },
        {
            "id": "39",
            "description": "सौतेला भाई (Sautela Bahi)",
            "name": "Step Brother"
        },
        {
            "id": "40",
            "description": "सौतेली बहन (Sauteli Bahan)",
            "name": "Step Sister"
        },
        {
            "id": "41",
            "description": "सौतेली माँ (Sauteli Maa)",
            "name": "Step Mother"
        },
        {
            "id": "42",
            "description": "सौतेला पिता (Sautala Pita)",
            "name": "Step Father"
        },
        {
            "id": "43",
            "description": "गोद लिया हुआ बेटा (God Liya Hua Beta)",
            "name": "Adopted Son"
        },
        {
            "id": "44",
            "description": "गोद ली हुई बेटी (God Li hui Beti)",
            "name": "Adopted Daughter"
        }
];x``

var flower =  [
        {
            "id": "1",
            "description": "गुलाब (Gulab)",
            "name": "Rose"
        },
        {
            "id": "2",
            "description": "कमल (Kamal)",
            "name": "Lotus"
        },
        {
            "id": "3",
            "description": "चमेली (Chameli)",
            "name": "Jasmine"
        },
        {
            "id": "4",
            "description": "सूरजमुखी (Surajmukhi)",
            "name": "Sunflower"
        },
        {
            "id": "5",
            "description": "गुडहल (Gudahal)",
            "name": "Hibiscus"
        },
        {
            "id": "6",
            "description": "गेंदा (Gainda)",
            "name": "Marigold"
        },
        {
            "id": "7",
            "description": "गुलबहार (Gulbahar)",
            "name": "Daisy"
        },
        {
            "id": "8",
            "description": "कुमुदिनी (Kumudini)",
            "name": "Lily"
        },
        {
            "id": "9",
            "description": "नीलकमल (Neelkamal)",
            "name": "Blue Water lily"
        },
        {
            "id": "10",
            "description": "चंपा (Champa)",
            "name": "Magnolia"
        },
        {
            "id": "11",
            "description": "कनेर (Kaner)",
            "name": "Oleander"
        },
        {
            "id": "12",
            "description": "कुमुद (Kumud)",
            "name": "Red lotus"
        },
        {
            "id": "13",
            "description": "चाँदनी (Chandani)",
            "name": "Crape Jasmine"
        },
        {
            "id": "14",
            "description": "छुई-मुई (Chhui-Mui)",
            "name": "Touch Me Not"
        },
        {
            "id": "15",
            "description": "गुलमेंहदी (Gulmehandi)",
            "name": "Balsam"
        },
        {
            "id": "16",
            "description": "माधवी पुष्प (Madhavi Pushp)",
            "name": "Hiptage"
        },
        {
            "id": "17",
            "description": "नलिनी (Nalini)",
            "name": "Tulip"
        },
        {
            "id": "18",
            "description": "पोस्ता (Posta)",
            "name": "Poppy"
        },
        {
            "id": "19",
            "description": "नरगिस (Nargis)",
            "name": "Narcissus"
        },
        {
            "id": "20",
            "description": "डहेलिया (Daheliya)",
            "name": "Dahlia"
        },
        {
            "id": "21",
            "description": "सदाबहार (Sadabahar)",
            "name": "Periwinkle"
        },
        {
            "id": "22",
            "description": "नाग चम्पा (Naag Champa)",
            "name": "Cobra Saffron"
        },
        {
            "id": "23",
            "description": "गुलदाउदी (Gul Daudi)",
            "name": "Chrysanthemum"
        }
];

var fruits =  [
        {
            "id": "1",
            "description": "आम (Aam)",
            "name": "Mango"
        },
        {
            "id": "2",
            "description": "सेब (Seb)",
            "name": "Apple"
        },
        {
            "id": "3",
            "description": "केला (Kela)",
            "name": "Banana"
        },
        {
            "id": "4",
            "description": "अनार (Anar)",
            "name": "Pomegranate"
        },
        {
            "id": "5",
            "description": "अंगूर (Angoor)",
            "name": "Grapes"
        },
        {
            "id": "6",
            "description": "संतरा (Santra)",
            "name": "Orange"
        },
        {
            "id": "7",
            "description": "चीकू (Chiku)",
            "name": "Sapota, Naseberry"
        },
        {
            "id": "8",
            "description": "आडू (Aadu)",
            "name": "Peach"
        },
        {
            "id": "9",
            "description": "पपीता (Papita)",
            "name": "Papaya"
        },
        {
            "id": "10",
            "description": "अमरुद (Amrood)",
            "name": "Guava"
        },
        {
            "id": "11",
            "description": "खरबूजा (Kharbooja)",
            "name": "Melon, Muskmelon"
        },
        {
            "id": "12",
            "description": "तरबूजा (Tarbooja)",
            "name": "Watermelon"
        },
        {
            "id": "13",
            "description": "अनन्नास (Anannas)",
            "name": "Pineapple"
        },
        {
            "id": "14",
            "description": "लीची (Lichi)",
            "name": "Lychee"
        },
        {
            "id": "15",
            "description": "नारियल (Nariyal)",
            "name": "Coconut"
        },
        {
            "id": "16",
            "description": "बेर (Ber)",
            "name": "Plum"
        },
        {
            "id": "17",
            "description": "फालसेब (Falseb)",
            "name": "Black Currant"
        },
        {
            "id": "18",
            "description": "रसभरी (Rasbhari)",
            "name": "Gooseberry Cape"
        },
        {
            "id": "19",
            "description": "शरीफा, सीताफल (Sharifa /Sitafal)",
            "name": "Custard Apple"
        },
        {
            "id": "20",
            "description": "खजूर (Khajoor)",
            "name": "Date"
        },
        {
            "id": "21",
            "description": "आँवला (Anvala)",
            "name": "Gooseberry"
        },
        {
            "id": "22",
            "description": "शहतूत (Shahtoot)",
            "name": "Mulbery"
        },
        {
            "id": "23",
            "description": "नाशपाती (Nashpati)",
            "name": "Pear"
        },
        {
            "id": "24",
            "description": "अंजीर (Anjeer)",
            "name": "Fig"
        },
        {
            "id": "25",
            "description": "चैरी (Chairi)",
            "name": "Cherry"
        },
        {
            "id": "26",
            "description": "कीवी (Kivi)",
            "name": "Kivi"
        },
        {
            "id": "27",
            "description": "आलू बुखारा (Aloo Bukhara)",
            "name": "Plum"
        },
        {
            "id": "28",
            "description": "मौसमी (Mausami)",
            "name": "Sweetlime, Sweet orange"
        },
        {
            "id": "29",
            "description": "बेल (Bel)",
            "name": "Wood Apple"
        },
        {
            "id": "30",
            "description": "सिंघाडा (Singhada)",
            "name": "Water Chestnut"
        },
        {
            "id": "31",
            "description": "जामुन (Jamun)",
            "name": "Black Cherry"
        },
        {
            "id": "32",
            "description": "मूँगफली (Moongfali)",
            "name": "Peanuts, Ground Nuts"
        },
        {
            "id": "33",
            "description": "गन्ना (Ganna)",
            "name": "Sugarcane"
        },
        {
            "id": "34",
            "description": "झरबेर (Jharber)",
            "name": "Strawberry"
        },
        {
            "id": "35",
            "description": "खूबानी (Khubani)",
            "name": "Apricot"
        },
        {
            "id": "36",
            "description": "इमली (Imali)",
            "name": "Tamarind"
        }
];

var fruit =  [
        {
            "id": "1",
            "name": "apple"
        },
        {
            "id": "2",
            "name": "apricot"
        },
        {
            "id": "3",
            "name": "avocado - the plural is avocados though you may see avocadoes (less frequently)."
        },
        {
            "id": "4",
            "name": "banana"
        },
        {
            "id": "5",
            "name": "blackberry"
        },
        {
            "id": "6",
            "name": "blackcurrant"
        },
        {
            "id": "7",
            "name": "blueberry"
        },
        {
            "id": "8",
            "name": "boysenberry - is a cross between a raspberry and a blackberry"
        },
        {
            "id": "9",
            "name": "cherry"
        },
        {
            "id": "10",
            "name": "coconut"
        },
        {
            "id": "11",
            "name": "fig"
        },
        {
            "id": "12",
            "name": "grape"
        },
        {
            "id": "13",
            "name": "grapefruit"
        },
        {
            "id": "14",
            "name": "kiwifruit - sometimes written as two words kiwi fruit. It has the same form in singular and plural kiwifruit."
        },
        {
            "id": "15",
            "name": "lemon"
        },
        {
            "id": "16",
            "name": "lime"
        },
        {
            "id": "17",
            "name": "lychee - sometimes called litchi in US English"
        },
        {
            "id": "18",
            "name": "mandarin"
        },
        {
            "id": "19",
            "name": "mango - the plural of mango can be either mangos or mangoes."
        },
        {
            "id": "20",
            "name": "melon - the generic name for most types of melon"
        },
        {
            "id": "21",
            "name": "nectarine - the same a peach but without fur on its skin"
        },
        {
            "id": "22",
            "name": "orange"
        },
        {
            "id": "23",
            "name": "papaya - In some countries it is called pawpaw."
        },
        {
            "id": "24",
            "name": "passion fruit - In United States it is written as two words while in some countries it is written as one word: passionfruit. The plural of passion fruit is either passion fruit or passion fruits. See our notes about the plural of fruit above."
        },
        {
            "id": "25",
            "name": "peach - same as a nectarine but with a slight fur on its skin"
        },
        {
            "id": "26",
            "name": "pear"
        },
        {
            "id": "27",
            "name": "pineapple"
        },
        {
            "id": "28",
            "name": "plum"
        },
        {
            "id": "29",
            "name": "pomegranate"
        },
        {
            "id": "30",
            "name": "quince"
        },
        {
            "id": "31",
            "name": "raspberry"
        },
        {
            "id": "32",
            "name": "strawberry"
        },
        {
            "id": "33",
            "name": "watermelon"
        },
        {
            "id": "34",
            "name": "Apple"
        },
        {
            "id": "35",
            "name": "Watermelon"
        },
        {
            "id": "36",
            "name": "Orange"
        },
        {
            "id": "37",
            "name": "Pear"
        },
        {
            "id": "38",
            "name": "Cherry"
        },
        {
            "id": "39",
            "name": "Strawberry"
        },
        {
            "id": "40",
            "name": "Nectarine"
        },
        {
            "id": "41",
            "name": "Grape"
        },
        {
            "id": "42",
            "name": "Mango"
        },
        {
            "id": "43",
            "name": "Blueberry"
        },
        {
            "id": "44",
            "name": "Pomegranate"
        },
        {
            "id": "45",
            "name": "Carambola(U.K) – starfruit (U.S)"
        },
        {
            "id": "46",
            "name": "Plum"
        },
        {
            "id": "47",
            "name": "Banana"
        },
        {
            "id": "48",
            "name": "Raspberry"
        },
        {
            "id": "49",
            "name": "Mandarin"
        },
        {
            "id": "50",
            "name": "Jackfruit"
        },
        {
            "id": "51",
            "name": "Papaya"
        },
        {
            "id": "52",
            "name": "Kiwi"
        },
        {
            "id": "53",
            "name": "Pineapple"
        },
        {
            "id": "54",
            "name": "Lime"
        },
        {
            "id": "55",
            "name": "Lemon"
        },
        {
            "id": "56",
            "name": "Apricot"
        },
        {
            "id": "57",
            "name": "Grapefruit"
        },
        {
            "id": "58",
            "name": "Melon"
        },
        {
            "id": "59",
            "name": "Coconut"
        },
        {
            "id": "60",
            "name": "Avocado"
        },
        {
            "id": "61",
            "name": "Peach"
        }
];

var fruitsVegatble = [
        {
            "id": "1",
            "name": "Alfalfa Sprouts"
        },
        {
            "id": "2",
            "name": "Apple"
        },
        {
            "id": "3",
            "name": "Apricot"
        },
        {
            "id": "4",
            "name": "Artichoke"
        },
        {
            "id": "5",
            "name": "Asian Pear"
        },
        {
            "id": "6",
            "name": "Asparagus"
        },
        {
            "id": "7",
            "name": "Atemoya"
        },
        {
            "id": "8",
            "name": "Avocado"
        },
        {
            "id": "9",
            "name": "Bamboo Shoots"
        },
        {
            "id": "10",
            "name": "Banana"
        },
        {
            "id": "11",
            "name": "Bean Sprouts"
        },
        {
            "id": "12",
            "name": "Beans"
        },
        {
            "id": "13",
            "name": "Beets"
        },
        {
            "id": "14",
            "name": "Belgian Endive"
        },
        {
            "id": "15",
            "name": "Bell Peppers"
        },
        {
            "id": "16",
            "name": "Bitter Melon"
        },
        {
            "id": "17",
            "name": "Blackberries"
        },
        {
            "id": "18",
            "name": "Blueberries"
        },
        {
            "id": "19",
            "name": "Bok Choy"
        },
        {
            "id": "20",
            "name": "Boniato"
        },
        {
            "id": "21",
            "name": "Boysenberries"
        },
        {
            "id": "22",
            "name": "Broccoflower"
        },
        {
            "id": "23",
            "name": "Broccoli"
        },
        {
            "id": "24",
            "name": "Brussels Sprouts"
        },
        {
            "id": "25",
            "name": "Cabbage"
        },
        {
            "id": "26",
            "name": "Cactus Pear"
        },
        {
            "id": "27",
            "name": "Cantaloupe"
        },
        {
            "id": "28",
            "name": "Carambola"
        },
        {
            "id": "29",
            "name": "Carrots"
        },
        {
            "id": "30",
            "name": "Casaba Melon"
        },
        {
            "id": "31",
            "name": "Cauliflower"
        },
        {
            "id": "32",
            "name": "Celery"
        },
        {
            "id": "33",
            "name": "Chayote"
        },
        {
            "id": "34",
            "name": "Cherimoya"
        },
        {
            "id": "35",
            "name": "Cherries"
        },
        {
            "id": "36",
            "name": "Coconuts"
        },
        {
            "id": "37",
            "name": "Collard Greens"
        },
        {
            "id": "38",
            "name": "Corn"
        },
        {
            "id": "39",
            "name": "Cranberries"
        },
        {
            "id": "40",
            "name": "Cucumber"
        },
        {
            "id": "41",
            "name": "Dates"
        },
        {
            "id": "42",
            "name": "Dried Plums"
        },
        {
            "id": "43",
            "name": "Eggplant"
        },
        {
            "id": "44",
            "name": "Endive"
        },
        {
            "id": "45",
            "name": "Escarole"
        },
        {
            "id": "46",
            "name": "Feijoa"
        },
        {
            "id": "47",
            "name": "Fennel"
        },
        {
            "id": "48",
            "name": "Figs"
        },
        {
            "id": "49",
            "name": "Garlic"
        },
        {
            "id": "50",
            "name": "Gooseberries"
        },
        {
            "id": "51",
            "name": "Grapefruit"
        },
        {
            "id": "52",
            "name": "Grapes"
        },
        {
            "id": "53",
            "name": "Green Beans"
        },
        {
            "id": "54",
            "name": "Green Onions"
        },
        {
            "id": "55",
            "name": "Greens"
        },
        {
            "id": "56",
            "name": "Guava"
        },
        {
            "id": "57",
            "name": "Hominy"
        },
        {
            "id": "58",
            "name": "Honeydew Melon"
        },
        {
            "id": "59",
            "name": "Horned Melon"
        },
        {
            "id": "60",
            "name": "Iceberg Lettuce"
        },
        {
            "id": "61",
            "name": "Jerusalem Artichoke"
        },
        {
            "id": "62",
            "name": "Jicama"
        },
        {
            "id": "63",
            "name": "Kale"
        },
        {
            "id": "64",
            "name": "Kiwifruit"
        },
        {
            "id": "65",
            "name": "Kohlrabi"
        },
        {
            "id": "66",
            "name": "Kumquat"
        },
        {
            "id": "67",
            "name": "Leeks"
        },
        {
            "id": "68",
            "name": "Lemons"
        },
        {
            "id": "69",
            "name": "Lettuce"
        },
        {
            "id": "70",
            "name": "Lima Beans"
        },
        {
            "id": "71",
            "name": "Limes"
        },
        {
            "id": "72",
            "name": "Longan"
        },
        {
            "id": "73",
            "name": "Loquat"
        },
        {
            "id": "74",
            "name": "Lychee"
        },
        {
            "id": "75",
            "name": "Madarins"
        },
        {
            "id": "76",
            "name": "Malanga"
        },
        {
            "id": "77",
            "name": "Mandarin Oranges"
        },
        {
            "id": "78",
            "name": "Mangos"
        },
        {
            "id": "79",
            "name": "Mulberries"
        },
        {
            "id": "80",
            "name": "Mushrooms"
        },
        {
            "id": "81",
            "name": "Napa"
        },
        {
            "id": "82",
            "name": "Nectarines"
        },
        {
            "id": "83",
            "name": "Okra"
        },
        {
            "id": "84",
            "name": "Onion"
        },
        {
            "id": "85",
            "name": "Oranges"
        },
        {
            "id": "86",
            "name": "Papayas"
        },
        {
            "id": "87",
            "name": "Parsnip"
        },
        {
            "id": "88",
            "name": "Passion Fruit"
        },
        {
            "id": "89",
            "name": "Peaches"
        },
        {
            "id": "90",
            "name": "Pears"
        },
        {
            "id": "91",
            "name": "Peas"
        },
        {
            "id": "92",
            "name": "Peppers"
        },
        {
            "id": "93",
            "name": "Persimmons"
        },
        {
            "id": "94",
            "name": "Pineapple"
        },
        {
            "id": "95",
            "name": "Plantains"
        },
        {
            "id": "96",
            "name": "Plums"
        },
        {
            "id": "97",
            "name": "Pomegranate"
        },
        {
            "id": "98",
            "name": "Potatoes"
        },
        {
            "id": "99",
            "name": "Prickly Pear"
        },
        {
            "id": "100",
            "name": "Prunes"
        },
        {
            "id": "101",
            "name": "Pummelo"
        },
        {
            "id": "102",
            "name": "Pumpkin"
        },
        {
            "id": "103",
            "name": "Quince"
        },
        {
            "id": "104",
            "name": "Radicchio"
        },
        {
            "id": "105",
            "name": "Radishes"
        },
        {
            "id": "106",
            "name": "Raisins"
        },
        {
            "id": "107",
            "name": "Raspberries"
        },
        {
            "id": "108",
            "name": "Red Cabbage"
        },
        {
            "id": "109",
            "name": "Rhubarb"
        },
        {
            "id": "110",
            "name": "Romaine Lettuce"
        },
        {
            "id": "111",
            "name": "Rutabaga"
        },
        {
            "id": "112",
            "name": "Shallots"
        },
        {
            "id": "113",
            "name": "Snow Peas"
        },
        {
            "id": "114",
            "name": "Spinach"
        },
        {
            "id": "115",
            "name": "Sprouts"
        },
        {
            "id": "116",
            "name": "Squash"
        },
        {
            "id": "117",
            "name": "Strawberries"
        },
        {
            "id": "118",
            "name": "String Beans"
        },
        {
            "id": "119",
            "name": "Sweet Potato"
        },
        {
            "id": "120",
            "name": "Tangelo"
        },
        {
            "id": "121",
            "name": "Tangerines"
        },
        {
            "id": "122",
            "name": "Tomatillo"
        },
        {
            "id": "123",
            "name": "Tomato"
        },
        {
            "id": "124",
            "name": "Turnip"
        },
        {
            "id": "125",
            "name": "Ugli Fruit"
        },
        {
            "id": "126",
            "name": "Water Chestnuts"
        },
        {
            "id": "127",
            "name": "Watercress"
        },
        {
            "id": "128",
            "name": "Watermelon"
        },
        {
            "id": "129",
            "name": "Waxed Beans"
        },
        {
            "id": "130",
            "name": "Yams"
        },
        {
            "id": "131",
            "name": "Yellow Squash"
        },
        {
            "id": "132",
            "name": "Yuca/Cassava"
        },
        {
            "id": "133",
            "name": "Zucchini Squash"
        }
];

var houseItems =  [
        {
            "id": "1",
            "description": "अलमारी (Almari)",
            "name": "Almirah"
        },
        {
            "id": "2",
            "description": "कंघा (Kangha)",
            "name": "Comb"
        },
        {
            "id": "3",
            "description": "कड़ाही (Kadahi)",
            "name": "Cauldron"
        },
        {
            "id": "4",
            "description": "कनस्तर (Kanastar)",
            "name": "Canister"
        },
        {
            "id": "5",
            "description": "कीप (Keep)",
            "name": "Funnel"
        },
        {
            "id": "6",
            "description": "कुर्सी (Kursi)",
            "name": "Chair"
        },
        {
            "id": "7",
            "description": "गिलास (Gilas)",
            "name": "Tumbler"
        },
        {
            "id": "8",
            "description": "चकला (Chakla)",
            "name": "Pastry board"
        },
        {
            "id": "9",
            "description": "चटाई (Chatai)",
            "name": "Mat"
        },
        {
            "id": "10",
            "description": "चमचा (Chamcha)",
            "name": "Spoon"
        },
        {
            "id": "11",
            "description": "चाबी (Chabi)",
            "name": "Key"
        },
        {
            "id": "12",
            "description": "चारपाई (Charpai)",
            "name": "Bed"
        },
        {
            "id": "13",
            "description": "चिमटा (Chimta)",
            "name": "Tongs"
        },
        {
            "id": "14",
            "description": "चूल्हा (Chulha)",
            "name": "Stove"
        },
        {
            "id": "15",
            "description": "गैस चूल्हा (Gas Chulha)",
            "name": "Gas Stove"
        },
        {
            "id": "16",
            "description": "तन्दूर (Tandoor)",
            "name": "Oven"
        },
        {
            "id": "17",
            "description": "टोकरी (Tokri)",
            "name": "Basket"
        },
        {
            "id": "18",
            "description": "तकिया (Takiya)",
            "name": "Pillow"
        },
        {
            "id": "19",
            "description": "सूई (Sooi)",
            "name": "Needle"
        },
        {
            "id": "20",
            "description": "सुराही (Surahi)",
            "name": "Jug"
        },
        {
            "id": "21",
            "description": "उस्तरा (Ustara)",
            "name": "Razor"
        },
        {
            "id": "22",
            "description": "कैंची (Kainchi)",
            "name": "Scissors"
        },
        {
            "id": "23",
            "description": "लोढ़ा (Lodha)",
            "name": "Pestle"
        },
        {
            "id": "24",
            "description": "काँटा (Kanta)",
            "name": "Fork"
        },
        {
            "id": "25",
            "description": "चलनी (Chalani)",
            "name": "Sieve"
        },
        {
            "id": "26",
            "description": "पीकदान (Peekdaan)",
            "name": "Spitoon"
        },
        {
            "id": "27",
            "description": "सन्दूक (sanduk)",
            "name": "Box"
        },
        {
            "id": "28",
            "description": "ब्रुश (Brush)",
            "name": "Brush"
        },
        {
            "id": "29",
            "description": "बाल्टी (Balti)",
            "name": "Bucket"
        },
        {
            "id": "30",
            "description": "बेलन (Belan)",
            "name": "Pastry Roller"
        },
        {
            "id": "31",
            "description": "बोतल (Botal)",
            "name": "Bottle"
        },
        {
            "id": "32",
            "description": "मसन्द (Masand)",
            "name": "Bolster"
        },
        {
            "id": "33",
            "description": "मोमबत्ती (Mombatti)",
            "name": "Candle"
        },
        {
            "id": "34",
            "description": "रस्सा (Rassa)",
            "name": "Rope"
        },
        {
            "id": "35",
            "description": "रस्सी (Rassi)",
            "name": "String"
        },
        {
            "id": "36",
            "description": "लोटा (Lota)",
            "name": "Drinking Vessel"
        },
        {
            "id": "37",
            "description": "शीशी (Shishi)",
            "name": "Phail"
        },
        {
            "id": "38",
            "description": "संडासी (Sandasi)",
            "name": "Pincers"
        },
        {
            "id": "39",
            "description": "सरौता (Sarauta)",
            "name": "Nut Cracker"
        },
        {
            "id": "40",
            "description": "साबुन (Sabun)",
            "name": "Soap"
        },
        {
            "id": "41",
            "description": "सिंगारदान (Singardab)",
            "name": "Casket"
        },
        {
            "id": "42",
            "description": "ताला (Tala)",
            "name": "Lock"
        },
        {
            "id": "43",
            "description": "तिजोरी (Tijori)",
            "name": "Safe"
        },
        {
            "id": "44",
            "description": "थाली (Thali)",
            "name": "Plate"
        },
        {
            "id": "45",
            "description": "दर्पण / शीशा (Darpan)",
            "name": "Mirror"
        },
        {
            "id": "46",
            "description": "माचिस (Machis)",
            "name": "Match"
        },
        {
            "id": "47",
            "description": "छाता (Chhata)",
            "name": "Umbrella"
        },
        {
            "id": "48",
            "description": "बर्तन (Bartan)",
            "name": "Pot"
        },
        {
            "id": "49",
            "description": "तवा (Tavaa)",
            "name": "Pan"
        },
        {
            "id": "50",
            "description": "प्रेस (Pres)",
            "name": "Iron"
        },
        {
            "id": "51",
            "description": "तराजू (Taraju)",
            "name": "Balance"
        },
        {
            "id": "52",
            "description": "पलंग (Palang)",
            "name": "Bestead"
        },
        {
            "id": "53",
            "description": "सोफा (Sofa)",
            "name": "Couch"
        }
];

var jewelry = [
        {
            "id": "1",
            "description": "गले का हार (Haar)",
            "name": "Necklace"
        },
        {
            "id": "2",
            "description": "अंगूठी (Anguthi)",
            "name": "Ring"
        },
        {
            "id": "3",
            "description": "झुमका, कर्णफूल, कुंडल (Jhumka)",
            "name": "Ear Ring"
        },
        {
            "id": "4",
            "description": "कान की बाली (Kaan Ki Bali)",
            "name": "Earstud"
        },
        {
            "id": "5",
            "description": "नाक की बाली (Naak Ki Bali)",
            "name": "Nose Ring"
        },
        {
            "id": "6",
            "description": "नथ, नाक पिन (Nath)",
            "name": "Nose Pin"
        },
        {
            "id": "7",
            "description": "चूड़ी, कड़ा (Chudi)",
            "name": "Bangle"
        },
        {
            "id": "8",
            "description": "कंगन (Kangan)",
            "name": "Bracelet"
        },
        {
            "id": "9",
            "description": "बाजूबंद (Bajuband)",
            "name": "Armlet"
        },
        {
            "id": "10",
            "description": "तोड़िया (Todiya)",
            "name": "Payal"
        },
        {
            "id": "11",
            "description": "लटकन (Latakan)",
            "name": "Pendant"
        },
        {
            "id": "12",
            "description": "मंगलसूत्र (Mangalsutra)",
            "name": "Mangalsutra"
        },
        {
            "id": "13",
            "description": "‎जंजीर (Janjir)",
            "name": "Chains"
        },
        {
            "id": "14",
            "description": "हीरा (Hira)",
            "name": "Diamond"
        },
        {
            "id": "15",
            "description": "मोती (Moti)",
            "name": "Pearl"
        },
        {
            "id": "16",
            "description": "नीलम (Nilam)",
            "name": "Sapphire"
        },
        {
            "id": "17",
            "description": "पन्ना (Panna)",
            "name": "Emerald"
        },
        {
            "id": "18",
            "description": "जवाहरात (Javahraat)",
            "name": "Gems"
        },
        {
            "id": "19",
            "description": "गोमेदक (Gomedak)",
            "name": "Zircon"
        }
];

var nationalFruits =  [
        {
            "SNo": "1",
            "Country": " Armenia",
            "name": "apricot",
            "Scientific_name": "Prunus armeniaca"
        },
        {
            "SNo": "2",
            "Country": " Bangladesh",
            "name": "jackfruit",
            "Scientific_name": "Artocarpus heterophyllus"
        },
        {
            "SNo": "3",
            "Country": " Brazil",
            "name": "cupuaçu",
            "Scientific_name": "Theobroma grandiflorum"
        },
        {
            "SNo": "4",
            "Country": "Cambodia",
            "name": "chicken egg banana",
            "Scientific_name": "Musa aromatica"
        },
        {
            "SNo": "5",
            "Country": "Cambodia",
            "name": "(chek pong moan in Khmer)"
        },
        {
            "SNo": "6",
            "Country": "China",
            "name": "fuzzy kiwi",
            "Scientific_name": "Actinidia deliciosa"
        },
        {
            "SNo": "7",
            "Country": "China",
            "name": "jujube",
            "Scientific_name": "Ziziphus zizyphus"
        },
        {
            "SNo": "8",
            "Country": " England",
            "name": "apple",
            "Scientific_name": "Malus domestica"
        },
        {
            "SNo": "9",
            "Country": "India",
            "name": "mango",
            "Scientific_name": "Mangifera indica"
        },
        {
            "SNo": "10",
            "Country": " Iran",
            "name": "pomegranate",
            "Scientific_name": "Punica granatum"
        },
        {
            "SNo": "11",
            "Country": " Jamaica",
            "name": "ackee",
            "Scientific_name": "Blighia sapida"
        },
        {
            "SNo": "12",
            "Country": " Japan",
            "name": "Japanese persimmon",
            "Scientific_name": "Diospyros kaki"
        },
        {
            "SNo": "13",
            "Country": " Malaysia",
            "name": "papaya",
            "Scientific_name": "Carica papaya"
        },
        {
            "SNo": "14",
            "Country": " Mexico",
            "name": "avocado",
            "Scientific_name": "Persea americana"
        },
        {
            "SNo": "15",
            "Country": " Pakistan",
            "name": "mango (Summer National fruit)",
            "Scientific_name": "Mangifera indica"
        },
        {
            "SNo": "16",
            "Country": " Pakistan",
            "name": "guava (Winter National fruit)",
            "Scientific_name": "Psidium"
        }
];

var metal = [
        {
            "id": "1",
            "description": "सोना (Sona)",
            "name": "Gold (गोल्ड)"
        },
        {
            "id": "2",
            "description": "चाँदी (Chandi)",
            "name": "Silver (सिलवर)"
        },
        {
            "id": "3",
            "description": "ताँवा (Tanva)",
            "name": "Copper (काँपर)"
        },
        {
            "id": "4",
            "description": "पीतल (Pital)",
            "name": "Brass (ब्रास)"
        },
        {
            "id": "5",
            "description": "काँसा (Kansa)",
            "name": "Bell Metal (बेलमेटल)"
        },
        {
            "id": "6",
            "description": "शीशा (Shlsha)",
            "name": "Lead (लेड)"
        },
        {
            "id": "7",
            "description": "जस्ता (Jasta)",
            "name": "Zink (जिंक)"
        },
        {
            "id": "8",
            "description": "लोहा (Loha)",
            "name": "Iron (आयरन)"
        },
        {
            "id": "9",
            "description": "इस्पात (Ispat)",
            "name": "Steel (स्टील)"
        },
        {
            "id": "10",
            "description": "रांगा (Ranga)",
            "name": "Tin (टिन)"
        }
];
var months = [
        {
            "id": "1",
            "description": "चैत्र / चैत (Chaitra)",
            "name": "March - April"
        },
        {
            "id": "2",
            "description": "वैशाख / बैसाख (Vaisakh)",
            "name": "April - May"
        },
        {
            "id": "3",
            "description": "जेष्ठ / जेठ (Jyeshtha)",
            "name": "May - June"
        },
        {
            "id": "4",
            "description": "आषाढ़ / आसाढ़ (Aashadh)",
            "name": "June - July"
        },
        {
            "id": "5",
            "description": "श्रवण / सावन (Shrawan)",
            "name": "July - August"
        },
        {
            "id": "6",
            "description": "भाद्रपद / भादो (Bhadrapad)",
            "name": "August - September"
        },
        {
            "id": "7",
            "description": "आश्विन (Ashvin)",
            "name": "September - October"
        },
        {
            "id": "8",
            "description": "कार्तिक / कातिक (Kartik)",
            "name": "October - November"
        },
        {
            "id": "9",
            "description": "अगहन (Agahan)",
            "name": "November - December"
        },
        {
            "id": "10",
            "description": "पौष / पूस (Paush)",
            "name": "December - January"
        },
        {
            "id": "11",
            "description": "माघ / माग॔शीष॔ (Magh)",
            "name": "January - February"
        },
        {
            "id": "12",
            "description": "फाल्गुन / फागुन (Phalgun)",
            "name": "February - March"
        }
];

var musical_Instrument = [
        {
            "id": "1",
            "description": "घंटी, घंटा",
            "name": "Bell"
        },
        {
            "id": "2",
            "description": "वीणा",
            "name": "Harp"
        },
        {
            "id": "3",
            "description": "झांझ, मजीरा",
            "name": "Cymbal"
        },
        {
            "id": "4",
            "description": "चंग, खञ्जरी",
            "name": "Tambourine"
        },
        {
            "id": "5",
            "description": "ढोल, नगाड़ा",
            "name": "Drum"
        },
        {
            "id": "6",
            "description": "ढोलक",
            "name": "Tomtom"
        },
        {
            "id": "7",
            "description": "तुरही, करनाई",
            "name": "Bugle"
        },
        {
            "id": "8",
            "description": "पियानो, पियानो बाजा",
            "name": "Piano"
        },
        {
            "id": "9",
            "description": "बांसुरी, बंशी, मुरली",
            "name": "Flute"
        },
        {
            "id": "10",
            "description": "सारंगी, बेला",
            "name": "Violin"
        },
        {
            "id": "11",
            "description": "मशक बाजा",
            "name": "Bagpipe"
        },
        {
            "id": "12",
            "description": "शहनाई",
            "name": "Clarinet"
        },
        {
            "id": "13",
            "description": "सीटी",
            "name": "Whistle"
        },
        {
            "id": "14",
            "description": "हारमोनियम, हरमोनियम बाजा",
            "name": "Harmonium"
        },
        {
            "id": "15",
            "description": "मरचंग, यहूदी सारंगी",
            "name": "Jew's harp"
        },
        {
            "id": "16",
            "description": "गिटार",
            "name": "Guitar"
        },
        {
            "id": "17",
            "description": "तुरही",
            "name": "Trumpet"
        }
];

var pet_animal=  [
        {
            "id": "1",
            "description": "गाय (Gay)",
            "name": "Cow"
        },
        {
            "id": "2",
            "description": "भैंस (Bains)",
            "name": "Buffalo"
        },
        {
            "id": "3",
            "description": "बकरी (Bakri)",
            "name": "Goat"
        },
        {
            "id": "4",
            "description": "भेंड़ (Bhed)",
            "name": "Sheep"
        },
        {
            "id": "5",
            "description": "बैल (Bail)",
            "name": "Ox"
        },
        {
            "id": "6",
            "description": "घोड़ा (Ghoda)",
            "name": "Horse"
        },
        {
            "id": "7",
            "description": "घोड़ी (Ghodi)",
            "name": "Mare"
        },
        {
            "id": "8",
            "description": "गधा (Gadha)",
            "name": "Donkey"
        },
        {
            "id": "9",
            "description": "खच्चर (khachchar)",
            "name": "Mule"
        },
        {
            "id": "10",
            "description": "कुत्ता (Kutta)",
            "name": "Dog"
        },
        {
            "id": "11",
            "description": "कुतिया (Kutiya)",
            "name": "Bitch"
        },
        {
            "id": "12",
            "description": "बिल्ली (Billi)",
            "name": "Cat"
        },
        {
            "id": "13",
            "description": "बन्दर (Bandar)",
            "name": "Monkey"
        },
        {
            "id": "14",
            "description": "ऊँट (Oont)",
            "name": "Camel"
        },
        {
            "id": "15",
            "description": "चूहा (Chuha)",
            "name": "Rat / Mouse"
        },
        {
            "id": "16",
            "description": "लंगूर (Langoor)",
            "name": "Ape"
        },
        {
            "id": "17",
            "description": "सूअर (Sooar)",
            "name": "Pig"
        },
        {
            "id": "18",
            "description": "याक (Yak)",
            "name": "Yak"
        },
        {
            "id": "19",
            "description": "गिलहरी (Gilhari)",
            "name": "Squirral"
        },
        {
            "id": "20",
            "description": "साँड़ (Sand)",
            "name": "Bull"
        }
];

var planet = [
        {
            "id": "1",
            "description": "सूर्य (Surya)",
            "name": "Sun"
        },
        {
            "id": "2",
            "description": "बुध (Budha)",
            "name": "Mercury"
        },
        {
            "id": "3",
            "description": "शुक्र (Śukra)",
            "name": "Venus"
        },
        {
            "id": "4",
            "description": "पृथ्वी (Prithvi)",
            "name": "Earth"
        },
        {
            "id": "5",
            "description": "मंगल (Mangal)",
            "name": "Mars"
        },
        {
            "id": "6",
            "description": "बृहस्पति (Brahspati)",
            "name": "Jupitar"
        },
        {
            "id": "7",
            "description": "शनि (Shani)",
            "name": "Saturn"
        },
        {
            "id": "8",
            "description": "अरुण (Arun)",
            "name": "Uranus"
        },
        {
            "id": "9",
            "description": "वरूण (Varun)",
            "name": "Neptune"
        },
        {
            "id": "10",
            "description": "यम (Yam)",
            "name": "Pluto"
        }
];

var rainbow_color = [
        {
            "id": "1",
            "description": "लाल (Lal)",
            "name": "Red"
        },
        {
            "id": "2",
            "description": "नारंगी (Narangi)",
            "name": "Orange"
        },
        {
            "id": "3",
            "description": "पीला (Peela)",
            "name": "Yellow"
        },
        {
            "id": "4",
            "description": "हरा (Hara)",
            "name": "Green"
        },
        {
            "id": "5",
            "description": "आसमानी (Asamani)",
            "name": "Sky Blue"
        },
        {
            "id": "6",
            "description": "नीला (Neela)",
            "name": "Blue"
        },
        {
            "id": "7",
            "description": "बैगनी (Baigni)",
            "name": "Purple, Violet"
        }
];

var rasi =  [
        {
            "id": "1",
            "description": "मेष (Mesh)",
            "name": "Aries",
            "desc2": "मेढा",
            "desc3": "मंगल",
            "desc4": "सिन्दूरी",
            "desc5": "मूंगा"
        },
        {
            "id": "2",
            "description": "वृषभ (Vrushabh)",
            "name": "Taurus",
            "desc2": "बेल",
            "desc3": "शुक्र",
            "desc4": "सफेद",
            "desc5": "हीरा"
        },
        {
            "id": "3",
            "description": "मिथुन (Mithun)",
            "name": "Gemini",
            "desc2": "युवा दंपत्ति",
            "desc3": "बुध",
            "desc4": "हरा",
            "desc5": "पन्ना"
        },
        {
            "id": "4",
            "description": "कर्क (Kark)",
            "name": "Cancer",
            "desc2": "कैकडा",
            "desc3": "चन्द्र",
            "desc4": "सफेद",
            "desc5": "मोती"
        },
        {
            "id": "5",
            "description": "सिंह (Sinh)",
            "name": "Leo",
            "desc2": "शेर",
            "desc3": "सूर्य",
            "desc4": "लाल",
            "desc5": "माणिक्य"
        },
        {
            "id": "6",
            "description": "कन्या (Kanya)",
            "name": "Virgo",
            "desc2": "कुमारी कन्या",
            "desc3": "बुध",
            "desc4": "हरा",
            "desc5": "पन्ना"
        },
        {
            "id": "7",
            "description": "तुला (Tula)",
            "name": "Libra",
            "desc2": "तराजू",
            "desc3": "शुक्र",
            "desc4": "सफेद",
            "desc5": "हीरा"
        },
        {
            "id": "8",
            "description": "वृश्चिक (Vrushchik)",
            "name": "Scorpius",
            "desc2": "बिच्छु",
            "desc3": "मंगल",
            "desc4": "सिन्दूरी",
            "desc5": "मूंगा"
        },
        {
            "id": "9",
            "description": "धनु (Dhanu)",
            "name": "Sagittarius",
            "desc2": "धनुष, धर्नुधारी",
            "desc3": "गुरु",
            "desc4": "पीला",
            "desc5": "पुखराज"
        },
        {
            "id": "10",
            "description": "मकर (Makar)",
            "name": "Capricornus",
            "desc2": "मगरमच्छ",
            "desc3": "शनि",
            "desc4": "नीला",
            "desc5": "नीलम"
        },
        {
            "id": "11",
            "description": "कुंभ (Kumbha)",
            "name": "Aquarius",
            "desc2": "घड़ा, कलश",
            "desc3": "शनि",
            "desc4": "नीला",
            "desc5": "नीलम"
        },
        {
            "id": "12",
            "description": "मीन (Meen)",
            "name": "Pisces",
            "desc2": "मछली",
            "desc3": "गुरु",
            "desc4": "पीला",
            "desc5": "पुखराज"
        }
];

var season_name = [
        {
            "id": "1",
            "description": "ग्रीष्म (Greesm)",
            "name": "Summer",
            "desc2": "ज्येष्ठ से आषाढ",
            "desc3": "मई से जून"
        },
        {
            "id": "2",
            "description": "वर्षा (Varsha)",
            "name": "Rainy",
            "desc2": "श्रावन से भाद्रपद",
            "desc3": "जुलाई से सितम्बर"
        },
        {
            "id": "3",
            "description": "शरद् (Sharad)",
            "name": "Autumn",
            "desc2": "आश्विन से कार्तिक",
            "desc3": "अक्टूबर से नवम्बर"
        },
        {
            "id": "4",
            "description": "हेमन्त (Hemant)",
            "name": "pre-winter",
            "desc2": "मार्गशीर्ष से पौष",
            "desc3": "दिसम्बर से 15 जनवरी"
        },
        {
            "id": "5",
            "description": "शिशिर (Shishir)",
            "name": "Winter",
            "desc2": "माघ से फाल्गुन",
            "desc3": "16 जनवरी से फरवरी"
        },
        {
            "id": "6",
            "description": "वसन्त (Vasant)",
            "name": "Spring",
            "desc2": "चैत्र से वैशाख",
            "desc3": "मार्च से अप्रैल"
        }
];

var vegetable = [
        {
            "id": "1",
            "description": "आलू (Aloo)",
            "name": "Potato"
        },
        {
            "id": "2",
            "description": "मटर (Matar)",
            "name": "Peas"
        },
        {
            "id": "3",
            "description": "टमाटर (Tamatar)",
            "name": "Tomato"
        },
        {
            "id": "4",
            "description": "बैगन (Baingan)",
            "name": "Brinjal"
        },
        {
            "id": "5",
            "description": "फूल गोभी (Fool Gobhi)",
            "name": "Cauliflower"
        },
        {
            "id": "6",
            "description": "पत्ता गोभी (Patta Gobhi)",
            "name": "Cabbage"
        },
        {
            "id": "7",
            "description": "भिन्डी (Bhindi)",
            "name": "Lady Finger"
        },
        {
            "id": "8",
            "description": "मूली (Muli)",
            "name": "Radish"
        },
        {
            "id": "9",
            "description": "प्याज (Pyaaj)",
            "name": "Onion"
        },
        {
            "id": "10",
            "description": "लहसुन (Lahasun)",
            "name": "Garlic"
        },
        {
            "id": "11",
            "description": "लौकी, घीया (Lauki, Gheeya)",
            "name": "Bottle Gourd"
        },
        {
            "id": "12",
            "description": "तुरई, तोरू (Turai, Toru)",
            "name": "Ridged Gourd"
        },
        {
            "id": "13",
            "description": "काशीफल, कद्दू (Kashifal, Kaddu)",
            "name": "Pumpkin"
        },
        {
            "id": "14",
            "description": "गाजर (Gajar)",
            "name": "Carrot"
        },
        {
            "id": "15",
            "description": "नीबू (Neebu)",
            "name": "Lemon"
        },
        {
            "id": "16",
            "description": "अदरक (Adrak)",
            "name": "Ginger"
        },
        {
            "id": "17",
            "description": "मिर्च (Mirch)",
            "name": "Chilli"
        },
        {
            "id": "18",
            "description": "हरी मिर्च (Hari Mirch)",
            "name": "Green pepper"
        },
        {
            "id": "19",
            "description": "शिमला मिर्च (Shimla Mirch)",
            "name": "Capsicum"
        },
        {
            "id": "20",
            "description": "पालक (Palak)",
            "name": "Spinach"
        },
        {
            "id": "21",
            "description": "हरी मैथी (Hari Maithee)",
            "name": "Fenugreek Leaf"
        },
        {
            "id": "22",
            "description": "बथुआ (Bathua)",
            "name": "White Goosefoot"
        },
        {
            "id": "23",
            "description": "हरा घनिया (Hara Dhaniya)",
            "name": "Coriander Leaf"
        },
        {
            "id": "24",
            "description": "टिंडा (Tinda)",
            "name": "Tinda"
        },
        {
            "id": "25",
            "description": "कमरक (Kamarak)",
            "name": "Starfruit"
        },
        {
            "id": "26",
            "description": "करोंदा (Karonda)",
            "name": "Natal Plum"
        },
        {
            "id": "27",
            "description": "खीरा (Kheera)",
            "name": "Cucumber"
        },
        {
            "id": "28",
            "description": "ककड़ी (Kakdee)",
            "name": "Cucumber"
        },
        {
            "id": "29",
            "description": "मक्का (Makka)",
            "name": "Corn, Maize"
        },
        {
            "id": "30",
            "description": "ग्वार की फली (Gwar Ki Fali)",
            "name": "Guar, Cluster Bean"
        },
        {
            "id": "31",
            "description": "मीठा नीम, कढ़ी पत्ता (Kadhi Patta)",
            "name": "Curry Leaf"
        },
        {
            "id": "32",
            "description": "कटहल (Kathal)",
            "name": "Jackfruit"
        },
        {
            "id": "33",
            "description": "शलजम (Shaljam)",
            "name": "Turnip"
        },
        {
            "id": "34",
            "description": "कुकुरमुत्ता (Kukurmutta)",
            "name": "Mushroom"
        },
        {
            "id": "35",
            "description": "पुदीना (Pudina)",
            "name": "Mint, Peppermint"
        },
        {
            "id": "36",
            "description": "शकरगंद (Shakargand)",
            "name": "Sweet Potato"
        },
        {
            "id": "37",
            "description": "जिमीकंद (Jimikand)",
            "name": "Taro, Yam"
        },
        {
            "id": "38",
            "description": "कच्चा केला (Kachcha Kela)",
            "name": "Cooking Plantain"
        },
        {
            "id": "39",
            "description": "चुकंदर (Chukundar)",
            "name": "Beetroot"
        },
        {
            "id": "40",
            "description": "करेला (Karela)",
            "name": "Bitter Gourd"
        },
        {
            "id": "41",
            "description": "अरवी (Arbi)",
            "name": "Colcassia"
        },
        {
            "id": "42",
            "description": "सेम फली (Sem Fali)",
            "name": "Bean Pod"
        },
        {
            "id": "43",
            "description": "कमल ककड़ी (Kamal Kakadi)",
            "name": "Lotus Stem"
        },
        {
            "id": "44",
            "description": "अमिया (Amiya)",
            "name": "Carry"
        },
        {
            "id": "45",
            "description": "रतालू (Ratalu)",
            "name": "Potato Palm"
        },
        {
            "id": "46",
            "description": "चौलाई (Chaulai)",
            "name": "Amaranth"
        },
        {
            "id": "47",
            "description": "पत्तों वाले प्याज (Patto Wale Pyaaj)",
            "name": "Spring Onion"
        },
        {
            "id": "48",
            "description": "सरसों पत्ता (Sarso Patta)",
            "name": "Mustard Greens"
        },
        {
            "id": "49",
            "description": "परवल (Parval)",
            "name": "Striped Pear Gourds"
        }
];

var vegetables= [
        {
            "id": "1",
            "name": "artichoke [C]"
        },
        {
            "id": "2",
            "name": "asparagus [U]"
        },
        {
            "id": "3",
            "name": "aubergine [C] and [U] - (called eggplant in United States)"
        },
        {
            "id": "4",
            "name": "beet [C] - (called beetroot in British English)"
        },
        {
            "id": "5",
            "name": "beetroot [C] and [U] - (called beet in United States)"
        },
        {
            "id": "6",
            "name": "bell pepper * [C] - (Just called pepper in British English or with its color beforehand just as red pepper or green pepper. In Australia and New Zealand it is known as capsicum)"
        },
        {
            "id": "7",
            "name": "broccoli [U] - (broccoli is an uncountable noun so there is no plural of broccoli)"
        },
        {
            "id": "8",
            "name": "Brussels sprout [C]"
        },
        {
            "id": "9",
            "name": "cabbage [C] and [U]"
        },
        {
            "id": "10",
            "name": "carrot [C]"
        },
        {
            "id": "11",
            "name": "cauliflower [C] and [U]"
        },
        {
            "id": "12",
            "name": "celery [U]"
        },
        {
            "id": "13",
            "name": "corn ** [U]"
        },
        {
            "id": "14",
            "name": "courgette * [C] - (called zucchini in United States)"
        },
        {
            "id": "15",
            "name": "cucumber * [C] and [U]"
        },
        {
            "id": "16",
            "name": "eggplant * [C] and [U] - (called aubergine in British English)"
        },
        {
            "id": "17",
            "name": "green bean * [C] - (sometimes called French bean in the UK)"
        },
        {
            "id": "18",
            "name": "green onion [C] - (called spring onion in the British English)"
        },
        {
            "id": "19",
            "name": "leek [C]"
        },
        {
            "id": "20",
            "name": "lettuce [C] and [U]"
        },
        {
            "id": "21",
            "name": "mushroom *** [C]"
        },
        {
            "id": "22",
            "name": "onion [C] and [U]"
        },
        {
            "id": "23",
            "name": "pea [C]"
        },
        {
            "id": "24",
            "name": "pepper [C] - (called bell pepper in British English. In Australia and New Zealand it is known as capsicum)"
        },
        {
            "id": "25",
            "name": "potato [C] and [U] - (the plural of potato is potatoes - potato is sometimes uncountable as in mashed potato)"
        },
        {
            "id": "26",
            "name": "pumpkin * [C] and [U]"
        },
        {
            "id": "27",
            "name": "radish [C] - (the plural of radish is radishes)"
        },
        {
            "id": "28",
            "name": "spring onion [C] - (called green onion or scallion in United States)"
        },
        {
            "id": "29",
            "name": "squash * [C] and [U]"
        },
        {
            "id": "30",
            "name": "sweet potato [C] - (kumara in New Zealand)"
        },
        {
            "id": "31",
            "name": "tomato * [C] - (the plural of tomato is tomatoes)"
        },
        {
            "id": "32",
            "name": "zucchini * [C] - (called courgette in British English)"
        }
];

var vehicle =  [
        {
            "id": "1",
            "name": "Van"
        },
        {
            "id": "2",
            "name": "Taxi"
        },
        {
            "id": "3",
            "name": "Police car"
        },
        {
            "id": "4",
            "name": "Bus"
        },
        {
            "id": "5",
            "name": "Ambulance"
        },
        {
            "id": "6",
            "name": "Skateboard"
        },
        {
            "id": "7",
            "name": "Baby carriage (US)/ Pram (UK)"
        },
        {
            "id": "8",
            "name": "Bicycle"
        },
        {
            "id": "9",
            "name": "Mountain bike"
        },
        {
            "id": "10",
            "name": "Scooter"
        },
        {
            "id": "11",
            "name": "Motorcycle"
        },
        {
            "id": "12",
            "name": "Fire engine"
        },
        {
            "id": "13",
            "name": "Crane"
        },
        {
            "id": "14",
            "name": "Forklift"
        },
        {
            "id": "15",
            "name": "Tractor"
        },
        {
            "id": "16",
            "name": "Recycling truck"
        },
        {
            "id": "17",
            "name": "Cement mixer"
        },
        {
            "id": "18",
            "name": "Dump truck"
        },
        {
            "id": "19",
            "name": "Subway"
        },
        {
            "id": "20",
            "name": "Aerial tramway"
        },
        {
            "id": "21",
            "name": "Helicopter"
        },
        {
            "id": "22",
            "name": "Airplane"
        },
        {
            "id": "23",
            "name": "Balloon"
        },
        {
            "id": "24",
            "name": "Tram (UK)/ Streetcar (US)"
        },
        {
            "id": "25",
            "name": "Carriage"
        },
        {
            "id": "26",
            "name": "Rowboat"
        },
        {
            "id": "27",
            "name": "Boat"
        },
        {
            "id": "28",
            "name": "Train"
        },
       
];

var wild_animal =  [
        {
            "id": "1",
            "description": "शेर (Sher)",
            "name": "Lion"
        },
        {
            "id": "2",
            "description": "चीता (Cheeta)",
            "name": "Tiger"
        },
        {
            "id": "3",
            "description": "लोमड़ी (Lomadi)",
            "name": "Fox"
        },
        {
            "id": "4",
            "description": "भेड़िया (Bhediya)",
            "name": "Wolf / Coyote"
        },
        {
            "id": "5",
            "description": "हिरन (Hiran)",
            "name": "Deer"
        },
        {
            "id": "6",
            "description": "भालू (Bhaloo)",
            "name": "Bear"
        },
        {
            "id": "7",
            "description": "हाथी (Hathi)",
            "name": "Elephant"
        },
        {
            "id": "8",
            "description": "सियार / गीदड़ (Siyar / Geedad)",
            "name": "Jackal"
        },
        {
            "id": "9",
            "description": "तेंदुआ (Tendua)",
            "name": "Leopard"
        },
        {
            "id": "10",
            "description": "बारहसिंगा (Barahsinga)",
            "name": "Stag"
        },
        {
            "id": "11",
            "description": "जिराफ (Giraf)",
            "name": "Zebra / Giraf"
        },
        {
            "id": "12",
            "description": "गैंड़ा (Gainda)",
            "name": "Rhinoceros"
        },
        {
            "id": "13",
            "description": "खरगोश (Khargosh)",
            "name": "Rabbit"
        },
        {
            "id": "14",
            "description": "वनमानुष (Vanmanush)",
            "name": "Gorilla"
        },
        {
            "id": "15",
            "description": "नील गाय (Neel gay)",
            "name": "Blue Bull"
        },
        {
            "id": "16",
            "description": "गिरगिट (Girgit)",
            "name": "Chameleon"
        },
        {
            "id": "17",
            "description": "चिंपाजी (Chimpaji)",
            "name": "Chimpanzee"
        },
        {
            "id": "18",
            "description": "शेरनी (Sherni)",
            "name": "Lioness /Tigress"
        },
        {
            "id": "19",
            "description": "हिरनी (Hirni)",
            "name": "Hind"
        },
        {
            "id": "20",
            "description": "नेवला (Nevala)",
            "name": "Mongoose"
        },
        {
            "id": "21",
            "description": "ध्रुवीय भालू (Dhruviy Bhaloo)",
            "name": "Polar Bear"
        },
        {
            "id": "22",
            "description": "कंगारू (Kangaroo)",
            "name": "Kangaroo"
        },
        {
            "id": "23",
            "description": "जंगली भैंसा (Jangli Bhainsa)",
            "name": "Bison"
        }
];

var count= [
        {
            "id": "1",
            "description": "एक (Ek)",
            "name": "One (वन)"
        },
        {
            "id": "2",
            "description": "दो (Do)",
            "name": "Two (टू)"
        },
        {
            "id": "3",
            "description": "तीन (Teen)",
            "name": "Three (थ्री)"
        },
        {
            "id": "4",
            "description": "चार (Chaar)",
            "name": "Four (फोर)"
        },
        {
            "id": "5",
            "description": "पाँच (Paanch)",
            "name": "Five (फाइव)"
        },
        {
            "id": "6",
            "description": "छ: (Chah)",
            "name": "Six (सिक्स)"
        },
        {
            "id": "7",
            "description": "सात (Saat)",
            "name": "Seven (सेवेन)"
        },
        {
            "id": "8",
            "description": "आठ (Aaath)",
            "name": "Eight (एट)"
        },
        {
            "id": "9",
            "description": "नौ (Nau)",
            "name": "Nine (नाइन)"
        },
        {
            "id": "10",
            "description": "दस (Das)",
            "name": "Ten (टेन)"
        },
        {
            "id": "11",
            "description": "ग्यारह (Gyarah)",
            "name": "Eleven (इलेवन)"
        },
        {
            "id": "12",
            "description": "बारह (Baarah)",
            "name": "Twelve (ट्वेल्व)"
        },
        {
            "id": "13",
            "description": "तेरह (Terah)",
            "name": "Thirteen (थर्टीन)"
        },
        {
            "id": "14",
            "description": "चौदह (Chaudah)",
            "name": "Fourteen (फोर्टीन)"
        },
        {
            "id": "15",
            "description": "पंद्रह (Pandrah)",
            "name": "Fifteen (फिफ्टीन)"
        },
        {
            "id": "16",
            "description": "सोलह (Solah)",
            "name": "Sixteen (सिक्सटीन)"
        },
        {
            "id": "17",
            "description": "सत्रह (Satrah)",
            "name": "Seventeen (सेवेनटीन)"
        },
        {
            "id": "18",
            "description": "अठारह (Athaarah)",
            "name": "Eighteen (एटीन)"
        },
        {
            "id": "19",
            "description": "उन्नीस (Unnees)",
            "name": "Nineteen (नाइनटीन)"
        },
        {
            "id": "20",
            "description": "बीस (Bees)",
            "name": "Twenty (ट्वेंटी)"
        },
        {
            "id": "21",
            "description": "इक्कीस (Ikkees)",
            "name": "Twenty One (ट्वेंटी वन)"
        },
        {
            "id": "22",
            "description": "बाईस (Baais)",
            "name": "Twenty Two (ट्वेंटी टू)"
        },
        {
            "id": "23",
            "description": "तेइस (Teis)",
            "name": "Twenty Three (ट्वेंटी थ्री)"
        },
        {
            "id": "24",
            "description": "चौबीस (Chaubees)",
            "name": "Twenty Four (ट्वेंटी फोर)"
        },
        {
            "id": "25",
            "description": "पच्चीस (Pachchees)",
            "name": "Twenty Five (ट्वेंटी फाइव)"
        },
        {
            "id": "26",
            "description": "छब्बीस (Chhabbees)",
            "name": "Twenty Six (ट्वेंटी सिक्स)"
        },
        {
            "id": "27",
            "description": "सत्ताईस (Sattaees)",
            "name": "Twenty Seven (ट्वेंटी सेवेन)"
        },
        {
            "id": "28",
            "description": "अट्ठाईस (Atthaees)",
            "name": "Twenty Eight (ट्वेंटी एट)"
        },
        {
            "id": "29",
            "description": "उनतीस (Unatees)",
            "name": "Twenty Nine (ट्वेंटी नाइन)"
        },
        {
            "id": "30",
            "description": "तीस (Tees)",
            "name": "Thirty (थर्टी)"
        },
        {
            "id": "31",
            "description": "इकतीस (Ikatees)",
            "name": "Thirty One (थर्टी वन)"
        },
        {
            "id": "32",
            "description": "बत्तीस (Battees)",
            "name": "Thirty Two (थर्टी टू)"
        },
        {
            "id": "33",
            "description": "तैंतीस (Taintees)",
            "name": "Thirty Three (थर्टी थ्री)"
        },
        {
            "id": "34",
            "description": "चौंतीस (Chauntees)",
            "name": "Thirty Four (थर्टी फोर)"
        },
        {
            "id": "35",
            "description": "पैंतीस (Paintees)",
            "name": "Thirty Five (थर्टी फाइव)"
        },
        {
            "id": "36",
            "description": "छत्तीस (Chhatees)",
            "name": "Thirty Six (थर्टी सिक्स)"
        },
        {
            "id": "37",
            "description": "सैंतीस (Saintees)",
            "name": "Thirty Seven (थर्टी सेवेन)"
        },
        {
            "id": "38",
            "description": "अड़तीस (Adatees)",
            "name": "Thirty Eight (थर्टी एट)"
        },
        {
            "id": "39",
            "description": "उनतालीस (Untaalees)",
            "name": "Thirty Nine (थर्टी नाइन)"
        },
        {
            "id": "40",
            "description": "चालीस (Chaalees)",
            "name": "Forty (फोर्टी)"
        },
        {
            "id": "41",
            "description": "इकतालीस (Ikataalees)",
            "name": "Forty One (फोर्टी वन)"
        },
        {
            "id": "42",
            "description": "बयालीस (Byalees)",
            "name": "Forty Two (फोर्टी टू)"
        },
        {
            "id": "43",
            "description": "तैंतालीस (Taintalees)",
            "name": "Forty Three (फोर्टी थ्री)"
        },
        {
            "id": "44",
            "description": "चवालीस (Chawalees)",
            "name": "Forty Four (फोर्टी फोर)"
        },
        {
            "id": "45",
            "description": "पैंतालीस (Paintalees)",
            "name": "Forty Five (फोर्टी फाइव)"
        },
        {
            "id": "46",
            "description": "छियालीस (Chhiyalees)",
            "name": "Forty Six (फोर्टी सिक्स)"
        },
        {
            "id": "47",
            "description": "सैंतालीस (Saintalees)",
            "name": "Forty Seven (फोर्टी सेवेन)"
        },
        {
            "id": "48",
            "description": "अड़तालीस (Adataalees)",
            "name": "Forty Eight (फोर्टी एट)"
        },
        {
            "id": "49",
            "description": "उड़नचास (Udanchaas)",
            "name": "Forty Nine (फोर्टी नाइन)"
        },
        {
            "id": "50",
            "description": "पचास (Pachaas)",
            "name": "Fifty (फिफ्टी)"
        },
        {
            "id": "51",
            "description": "इक्यावन (Ikyaavan)",
            "name": "Fifty One (फिफ्टी वन)"
        },
        {
            "id": "52",
            "description": "बावन (Baawan)",
            "name": "Fifty Two (फिफ्टी टू)"
        },
        {
            "id": "53",
            "description": "तिरेपन (Tirepan)",
            "name": "Fifty Three (फिफ्टी थ्री)"
        },
        {
            "id": "54",
            "description": "चौवन (Chauwan)",
            "name": "Fifty Four (फिफ्टी फोर)"
        },
        {
            "id": "55",
            "description": "पचपन (Pachapan)",
            "name": "Fifty Five (फिफ्टी फाइव)"
        },
        {
            "id": "56",
            "description": "छप्पन (Chhappan)",
            "name": "Fifty Six (फिफ्टी सिक्स)"
        },
        {
            "id": "57",
            "description": "सत्तावन (Sattaavan)",
            "name": "Fifty Seven (फिफ्टी सेवेन)"
        },
        {
            "id": "58",
            "description": "अट्ठावन (Atthaavan)",
            "name": "Fifty Eight (फिफ्टी एट)"
        },
        {
            "id": "59",
            "description": "उनसठ (Unsath)",
            "name": "Fifty Nine (फिफ्टी नाइन)"
        },
        {
            "id": "60",
            "description": "साठ (Saath)",
            "name": "Sixty (सिक्सटी)"
        },
        {
            "id": "61",
            "description": "इकसठ (Ikasath)",
            "name": "Sixty One (सिक्सटी वन)"
        },
        {
            "id": "62",
            "description": "बासठ (Baasath)",
            "name": "Sixty Two (सिक्सटी टू)"
        },
        {
            "id": "63",
            "description": "तिरेसठ (Tiresath)",
            "name": "Sixty Three (सिक्सटी थ्री)"
        },
        {
            "id": "64",
            "description": "चौंसठ (Chausath)",
            "name": "Sixty Four (सिक्सटी फोर)"
        },
        {
            "id": "65",
            "description": "पैंसठ (Painsath)",
            "name": "Sixty Five (सिक्सटी फाइव)"
        },
        {
            "id": "66",
            "description": "छियासठ (Chhiyasath)",
            "name": "Sixty Six (सिक्सटी सिक्स)"
        },
        {
            "id": "67",
            "description": "सड़सठ (Sadasath)",
            "name": "Sixty Seven (सिक्सटी सेवेन)"
        },
        {
            "id": "68",
            "description": "अड़सठ (Adasath)",
            "name": "Sixty Eight (सिक्सटी एट)"
        },
        {
            "id": "69",
            "description": "उनहत्तर (Unahattar)",
            "name": "Sixty Nine (सिक्सटी नाइन)"
        },
        {
            "id": "70",
            "description": "सत्तर (Sattar)",
            "name": "Seventy (सेवेनटी)"
        },
        {
            "id": "71",
            "description": "इकहत्तर (Ikahattar)",
            "name": "Seventy One (सेवेनटी वन)"
        },
        {
            "id": "72",
            "description": "बहत्तर (Bahattar)",
            "name": "Seventy Two (सेवेनटी टू)"
        },
        {
            "id": "73",
            "description": "तिहत्तर (Tihattar)",
            "name": "Seventy Three (सेवेनटी थ्री)"
        },
        {
            "id": "74",
            "description": "चौहत्तर (Chauhattar)",
            "name": "Seventy Four (सेवेनटी फोर)"
        },
        {
            "id": "75",
            "description": "पिचहत्तर (Pichahattar)",
            "name": "Seventy Five (सेवेनटी फाइव)"
        },
        {
            "id": "76",
            "description": "छिहत्तर (Chhihattar)",
            "name": "Seventy Six (सेवेनटी सिक्स)"
        },
        {
            "id": "77",
            "description": "सतत्तर (Satattar)",
            "name": "Seventy Seven (सेवेनटी सेवेन)"
        },
        {
            "id": "78",
            "description": "अठहत्तर (Athahattar)",
            "name": "Seventy Eight (सेवेनटी एट)"
        },
        {
            "id": "79",
            "description": "उनासी (Unaasi)",
            "name": "Seventy Nine (सेवेनटी नाइन)"
        },
        {
            "id": "80",
            "description": "अस्सी (Assi)",
            "name": "Eighty (एटी)"
        },
        {
            "id": "81",
            "description": "इक्यासी (Ikyaasi)",
            "name": "Eighty One (एटी वन)"
        },
        {
            "id": "82",
            "description": "बियासी (Biyaasi)",
            "name": "Eighty Two (एटी टू)"
        },
        {
            "id": "83",
            "description": "तिरासी (Tiraasi)",
            "name": "Eighty Three (एटी थ्री)"
        },
        {
            "id": "84",
            "description": "चौरासी (Chauraasi)",
            "name": "Eighty Four (एटी फोर)"
        },
        {
            "id": "85",
            "description": "पिचासी (Pichaasi)",
            "name": "Eighty Five (एटी फाइव)"
        },
        {
            "id": "86",
            "description": "छियासी (Chhiyaasi)",
            "name": "Eighty Six (एटी सिक्स)"
        },
        {
            "id": "87",
            "description": "सतासी (Sattasi)",
            "name": "Eighty Seven (एटी सेवेन)"
        },
        {
            "id": "88",
            "description": "अट्ठासी (Atthaasi)",
            "name": "Eighty Eight (एटी एट)"
        },
        {
            "id": "89",
            "description": "नवासी (Navaasi)",
            "name": "Eighty Nine (एटी नाइन)"
        },
        {
            "id": "90",
            "description": "नब्बे (Nabbe)",
            "name": "Ninety (नाइनटी)"
        },
        {
            "id": "91",
            "description": "इक्यानवे (Ikyaanve)",
            "name": "Ninety One (नाइनटी वन)"
        },
        {
            "id": "92",
            "description": "बानवे (Baanave)",
            "name": "Ninety Two (नाइनटी टू)"
        },
        {
            "id": "93",
            "description": "तिरानवे (Tiraanave)",
            "name": "Ninety Three (नाइनटी थ्री)"
        },
        {
            "id": "94",
            "description": "चौरानवे (Chauraanave)",
            "name": "Ninety Four (नाइनटी फोर)"
        },
        {
            "id": "95",
            "description": "पिचानवे (Pichaanave)",
            "name": "Ninety Five (नाइनटी फाइव)"
        },
        {
            "id": "96",
            "description": "छियानवे (Chhiyaanave)",
            "name": "Ninety Six (नाइनटी सिक्स)"
        },
        {
            "id": "97",
            "description": "सत्तानवे (Sattaanave)",
            "name": "Ninety Seven (नाइनटी सेवेन)"
        },
        {
            "id": "98",
            "description": "अट्ठानवे (Atthaanave)",
            "name": "Ninety Eight (नाइनटी एट)"
        },
        {
            "id": "99",
            "description": "निन्यानवे (Ninyaanave)",
            "name": "Ninety Nine (नाइनटी नाइन)"
        },
        {
            "id": "100",
            "description": "सौ (Sau)",
            "name": "Hundred (हंड्रेड)"
        }
];


var utensil =  [
        {
            "id": "1",
            "name": "Kettle "
        },
        {
            "id": "2",
            "name": "        Toaster "
        },
        {
            "id": "3",
            "name": "        Microwave oven "
        },
        {
            "id": "4",
            "name": "        Refrigerator (commonly “fridge”) "
        },
        {
            "id": "5",
            "name": "        Dishwasher "
        },
        {
            "id": "6",
            "name": "        Breadbox "
        },
        {
            "id": "7",
            "name": "        Pitcher (or jug) "
        },
        {
            "id": "8",
            "name": "        Blender "
        },
        {
            "id": "9",
            "name": "        Colander "
        },
        {
            "id": "10",
            "name": "        Tureen (or bowl) "
        },
        {
            "id": "11",
            "name": "        Cookware "
        },
        {
            "id": "12",
            "name": "        Frying pan (stainless steel or nonstick)"
        },
        {
            "id": "13",
            "name": "        Teapot "
        },
        {
            "id": "14",
            "name": "        Grater"
        },
        {
            "id": "15",
            "name": "         Spatula"
        },
        {
            "id": "16",
            "name": "        Measuring cups"
        },
        {
            "id": "17",
            "name": "        Measuring spoons"
        },
        {
            "id": "18",
            "name": "        Cutting board"
        },
        {
            "id": "19",
            "name": "        Ladle"
        },
        {
            "id": "20",
            "name": "        Strainer"
        },
        {
            "id": "21",
            "name": "        Slotted spoon"
        },
        {
            "id": "22",
            "name": "        Can opener"
        },
        {
            "id": "23",
            "name": "        Mixing bowl"
        },
        {
            "id": "24",
            "name": "        Egg slicer"
        },
        {
            "id": "25",
            "name": "        Potato peeler "
        },
        {
            "id": "26",
            "name": "        Meat mallet"
        },
        {
            "id": "27",
            "name": "        Plate "
        },
        {
            "id": "28",
            "name": "        Glass "
        },
        {
            "id": "29",
            "name": "        Cup (mug) "
        },
        {
            "id": "30",
            "name": "        Regular spoon "
        },
        {
            "id": "31",
            "name": "        Fork "
        },
        {
            "id": "32",
            "name": "        Knife (butter knife, paring knife, steak knife)"
        },
        {
            "id": "33",
            "name": "        Bin "
        },
        {
            "id": "34",
            "name": "Apron"
        },
        {
            "id": "35",
            "name": "Bread basket"
        },
        {
            "id": "36",
            "name": "Bowl"
        },
        {
            "id": "37",
            "name": "Teapot"
        },
        {
            "id": "38",
            "name": "Measuring cup"
        },
        {
            "id": "39",
            "name": "Baking tray"
        },
        {
            "id": "40",
            "name": "Timer"
        },
        {
            "id": "41",
            "name": "Spice container"
        },
        {
            "id": "42",
            "name": "Chopping board"
        },
        {
            "id": "43",
            "name": "Grater"
        },
        {
            "id": "44",
            "name": "Pie plate"
        },
        {
            "id": "45",
            "name": "Salad spinner"
        },
        {
            "id": "46",
            "name": "Colander"
        },
        {
            "id": "47",
            "name": "Butter dish"
        },
        {
            "id": "48",
            "name": "Oven glove"
        },
        {
            "id": "49",
            "name": "Napkin"
        },
        {
            "id": "50",
            "name": "Chopsticks"
        },
        {
            "id": "51",
            "name": "Rolling pin"
        },
        {
            "id": "52",
            "name": "Measuring spoon"
        },
        {
            "id": "53",
            "name": "Whisk"
        },
        {
            "id": "54",
            "name": "Wooden spoon"
        },
        {
            "id": "55",
            "name": "Strainer"
        },
        {
            "id": "56",
            "name": "Steak hammer"
        },
        {
            "id": "57",
            "name": "Spoon"
        },
        {
            "id": "58",
            "name": "Spatula"
        },
        {
            "id": "59",
            "name": "Mesh skimmer"
        },
        {
            "id": "60",
            "name": "Cleaver"
        },
        {
            "id": "61",
            "name": "Ladle"
        },
        {
            "id": "62",
            "name": "Knife"
        },
        {
            "id": "63",
            "name": "Kitchen shears"
        },
        {
            "id": "64",
            "name": "Fork"
        },
        {
            "id": "65",
            "name": "Cutlery"
        },
        {
            "id": "66",
            "name": "Corkscrew"
        },
        {
            "id": "67",
            "name": "Cake slice"
        },
        {
            "id": "68",
            "name": "Saucepan (U.K) – pot (U.S)"
        },
        {
            "id": "69",
            "name": "Frying pan"
        },
        {
            "id": "70",
            "name": "Pressure cooker"
        },
        {
            "id": "71",
            "name": "Cooker"
        },
        {
            "id": "72",
            "name": "Casserole dish"
        }
];
var food_preapre = [
        {
            "id": "1",
            "name": "Apple corer"
        },
        {
            "id": "2",
            "name": "Apple cutter"
        },
        {
            "id": "3",
            "name": "Baster"
        },
        {
            "id": "4",
            "name": "Beanpot"
        },
        {
            "id": "5",
            "name": "Biscuit press"
        },
        {
            "id": "6",
            "name": "Blow torch"
        },
        {
            "id": "7",
            "name": "Boil over preventer"
        },
        {
            "id": "8",
            "name": "Bottle opener"
        },
        {
            "id": "9",
            "name": "Bowl"
        },
        {
            "id": "10",
            "name": "Bread knife"
        },
        {
            "id": "11",
            "name": "Browning tray"
        },
        {
            "id": "12",
            "name": "Butter curler"
        },
        {
            "id": "13",
            "name": "Cake and pie server"
        },
        {
            "id": "14",
            "name": "Cheese cutter"
        },
        {
            "id": "15",
            "name": "Cheese knife"
        },
        {
            "id": "16",
            "name": "Cheese slicer"
        },
        {
            "id": "17",
            "name": "Cheesecloth"
        },
        {
            "id": "18",
            "name": "Chef's knife"
        },
        {
            "id": "19",
            "name": "Cherry pitter"
        },
        {
            "id": "20",
            "name": "Chinois"
        },
        {
            "id": "21",
            "name": "Clay pot"
        },
        {
            "id": "22",
            "name": "Cleaver"
        },
        {
            "id": "23",
            "name": "Colander"
        },
        {
            "id": "24",
            "name": "Cookie cutter"
        },
        {
            "id": "25",
            "name": "Corkscrew"
        },
        {
            "id": "26",
            "name": "Crab cracker"
        },
        {
            "id": "27",
            "name": "Cutting board"
        },
        {
            "id": "28",
            "name": "Dough scraper"
        },
        {
            "id": "29",
            "name": "Edible tableware"
        },
        {
            "id": "30",
            "name": "Egg piercer"
        },
        {
            "id": "31",
            "name": "Egg poacher"
        },
        {
            "id": "32",
            "name": "Egg separator"
        },
        {
            "id": "33",
            "name": "Egg slicer"
        },
        {
            "id": "34",
            "name": "Egg timer"
        },
        {
            "id": "35",
            "name": "Fat separator"
        },
        {
            "id": "36",
            "name": "Fillet knife"
        },
        {
            "id": "37",
            "name": "Fish scaler"
        },
        {
            "id": "38",
            "name": "Fish slice"
        },
        {
            "id": "39",
            "name": "Flour sifter"
        },
        {
            "id": "40",
            "name": "Food mill"
        },
        {
            "id": "41",
            "name": "Funnel"
        },
        {
            "id": "42",
            "name": "Garlic press"
        },
        {
            "id": "43",
            "name": "Grapefruit knife"
        },
        {
            "id": "44",
            "name": "Grater"
        },
        {
            "id": "45",
            "name": "Gravy strainer"
        },
        {
            "id": "46",
            "name": "Herb chopper"
        },
        {
            "id": "47",
            "name": "Honey dipper"
        },
        {
            "id": "48",
            "name": "Ladle"
        },
        {
            "id": "49",
            "name": "Lame"
        },
        {
            "id": "50",
            "name": "Lemon reamer"
        },
        {
            "id": "51",
            "name": "Lemon squeezer"
        },
        {
            "id": "52",
            "name": "Lobster pick"
        },
        {
            "id": "53",
            "name": "Mandoline"
        },
        {
            "id": "54",
            "name": "Mated colander pot"
        },
        {
            "id": "55",
            "name": "Measuring cup"
        },
        {
            "id": "56",
            "name": "Measuring spoon"
        },
        {
            "id": "57",
            "name": "Meat grinder"
        },
        {
            "id": "58",
            "name": "Meat tenderiser"
        },
        {
            "id": "59",
            "name": "Meat thermometer"
        },
        {
            "id": "60",
            "name": "Melon baller"
        },
        {
            "id": "61",
            "name": "Mezzaluna"
        },
        {
            "id": "62",
            "name": "Microplane"
        },
        {
            "id": "63",
            "name": "Milk frother"
        },
        {
            "id": "64",
            "name": "Mortar and pestle"
        },
        {
            "id": "65",
            "name": "Nutcracker"
        },
        {
            "id": "66",
            "name": "Nutmeg grater"
        },
        {
            "id": "67",
            "name": "Oven glove"
        },
        {
            "id": "68",
            "name": "Pastry bag"
        },
        {
            "id": "69",
            "name": "Pastry blender"
        },
        {
            "id": "70",
            "name": "Pastry brush"
        },
        {
            "id": "71",
            "name": "Pastry wheel"
        },
        {
            "id": "72",
            "name": "Peel"
        },
        {
            "id": "73",
            "name": "Peeler"
        },
        {
            "id": "74",
            "name": "Pepper mill"
        },
        {
            "id": "75",
            "name": "Pie bird"
        },
        {
            "id": "76",
            "name": "Pizza cutter"
        },
        {
            "id": "77",
            "name": "Potato masher"
        },
        {
            "id": "78",
            "name": "Potato ricer"
        },
        {
            "id": "79",
            "name": "Pot-holder"
        },
        {
            "id": "80",
            "name": "Poultry shears"
        },
        {
            "id": "81",
            "name": "Roller docker"
        },
        {
            "id": "82",
            "name": "Rolling pin"
        },
        {
            "id": "83",
            "name": "Salt shaker"
        },
        {
            "id": "84",
            "name": "Scales"
        },
        {
            "id": "85",
            "name": "Scissors"
        },
        {
            "id": "86",
            "name": "Scoop"
        },
        {
            "id": "87",
            "name": "Sieve"
        },
        {
            "id": "88",
            "name": "Slotted spoon"
        },
        {
            "id": "89",
            "name": "Spatula"
        },
        {
            "id": "90",
            "name": "Spider"
        },
        {
            "id": "91",
            "name": "Sugar thermometer"
        },
        {
            "id": "92",
            "name": "Tamis"
        },
        {
            "id": "93",
            "name": "Tin opener"
        },
        {
            "id": "94",
            "name": "Tomato knife"
        },
        {
            "id": "95",
            "name": "Tongs"
        },
        {
            "id": "96",
            "name": "Trussing needle"
        },
        {
            "id": "97",
            "name": "Twine"
        },
        {
            "id": "98",
            "name": "Whisk"
        },
        {
            "id": "99",
            "name": "Wooden spoon"
        },
        {
            "id": "100",
            "name": "Zester"
        }
];

var cokking_applience=[
        {
            "id": "1",
            "name": "Air fryer"
        },
        {
            "id": "2",
            "name": "Bachelor griller"
        },
        {
            "id": "3",
            "name": "Barbecue grill"
        },
        {
            "id": "4",
            "name": "Beehive oven"
        },
        {
            "id": "5",
            "name": "Brasero (heater)"
        },
        {
            "id": "6",
            "name": "Brazier"
        },
        {
            "id": "7",
            "name": "Bread machine"
        },
        {
            "id": "8",
            "name": "Burjiko"
        },
        {
            "id": "9",
            "name": "Butane torch"
        },
        {
            "id": "10",
            "name": "Chapati maker"
        },
        {
            "id": "11",
            "name": "Cheesemelter"
        },
        {
            "id": "12",
            "name": "Chocolatera"
        },
        {
            "id": "13",
            "name": "Chorkor oven"
        },
        {
            "id": "14",
            "name": "Clome oven"
        },
        {
            "id": "15",
            "name": "Comal (cookware)"
        },
        {
            "id": "16",
            "name": "Combi steamer"
        },
        {
            "id": "17",
            "name": "Communal oven"
        },
        {
            "id": "18",
            "name": "Convection microwave"
        },
        {
            "id": "19",
            "name": "Convection oven"
        },
        {
            "id": "20",
            "name": "Corn roaster"
        },
        {
            "id": "21",
            "name": "Crepe maker"
        },
        {
            "id": "22",
            "name": "Deep fryer"
        },
        {
            "id": "23",
            "name": "Earth oven"
        },
        {
            "id": "24",
            "name": "Electric cooker"
        },
        {
            "id": "25",
            "name": "Energy regulator"
        },
        {
            "id": "26",
            "name": "Espresso machine"
        },
        {
            "id": "27",
            "name": "Field kitchen"
        },
        {
            "id": "28",
            "name": "Fire pot"
        },
        {
            "id": "29",
            "name": "Flattop grill"
        },
        {
            "id": "30",
            "name": "Food steamer"
        },
        {
            "id": "31",
            "name": "Fufu Machine"
        },
        {
            "id": "32",
            "name": "Halogen oven"
        },
        {
            "id": "33",
            "name": "Haybox"
        },
        {
            "id": "34",
            "name": "Horno"
        },
        {
            "id": "35",
            "name": "Hot box (appliance)"
        },
        {
            "id": "36",
            "name": "Hot plate"
        },
        {
            "id": "37",
            "name": "Instant Pot"
        },
        {
            "id": "38",
            "name": "Kamado"
        },
        {
            "id": "39",
            "name": "Kettle"
        },
        {
            "id": "40",
            "name": "Kitchener range"
        },
        {
            "id": "41",
            "name": "Kujiejun"
        },
        {
            "id": "42",
            "name": "Kyoto box"
        },
        {
            "id": "43",
            "name": "Makiyakinabe"
        },
        {
            "id": "44",
            "name": "Masonry oven"
        },
        {
            "id": "45",
            "name": "Mess kit"
        },
        {
            "id": "46",
            "name": "Microwave oven"
        },
        {
            "id": "47",
            "name": "Multicooker"
        },
        {
            "id": "48",
            "name": "Oven"
        },
        {
            "id": "49",
            "name": "Pancake machine"
        },
        {
            "id": "50",
            "name": "Panini sandwich grill"
        },
        {
            "id": "51",
            "name": "Popcorn maker"
        },
        {
            "id": "52",
            "name": "Pressure cooker"
        },
        {
            "id": "53",
            "name": "Pressure fryer"
        },
        {
            "id": "54",
            "name": "Reflector oven"
        },
        {
            "id": "55",
            "name": "Remoska"
        },
        {
            "id": "56",
            "name": "Rice cooker"
        },
        {
            "id": "57",
            "name": "Rice polisher"
        },
        {
            "id": "58",
            "name": "Roasting jack"
        },
        {
            "id": "59",
            "name": "Rocket mass heater"
        },
        {
            "id": "60",
            "name": "Rotimatic"
        },
        {
            "id": "61",
            "name": "Rotisserie"
        },
        {
            "id": "62",
            "name": "Russian oven"
        },
        {
            "id": "63",
            "name": "Sabbath mode"
        },
        {
            "id": "64",
            "name": "Salamander broiler"
        },
        {
            "id": "65",
            "name": "Samovar"
        },
        {
            "id": "66",
            "name": "Sandwich toaster"
        },
        {
            "id": "67",
            "name": "Self-cleaning oven"
        },
        {
            "id": "68",
            "name": "Shichirin"
        },
        {
            "id": "69",
            "name": "Slow cooker"
        },
        {
            "id": "70",
            "name": "Solar cooker"
        },
        {
            "id": "71",
            "name": "Sous-vide cooker"
        },
        {
            "id": "72",
            "name": "Soy milk maker"
        },
        {
            "id": "73",
            "name": "Stove"
        },
        {
            "id": "74",
            "name": "Susceptor"
        },
        {
            "id": "75",
            "name": "Tabun oven"
        },
        {
            "id": "76",
            "name": "Tandoor"
        },
        {
            "id": "77",
            "name": "Tangia"
        },
        {
            "id": "78",
            "name": "Thermal immersion circulator"
        },
        {
            "id": "79",
            "name": "Toaster and toaster ovens"
        },
        {
            "id": "80",
            "name": "Turkey fryer"
        },
        {
            "id": "81",
            "name": "Vacuum fryer "
        },
        {
            "id": "82",
            "name": "Waffle iron"
        },
        {
            "id": "83",
            "name": "Wet grinder"
        },
        {
            "id": "84",
            "name": "Wood-fired oven"
        },
        {
            "id": "85",
            "name": "Coffee percolator"
        },
        {
            "id": "86",
            "name": "Coffeemaker"
        },
        {
            "id": "87",
            "name": "Electric water boiler"
        },
        {
            "id": "88",
            "name": "Instant hot water dispenser"
        }
];


var bathroom_ass= [
        {
            "id": "1",
            "name": "Bath mirrors"
        },
        {
            "id": "2"
        },
        {
            "id": "3",
            "name": "Make-up mirrors"
        },
        {
            "id": "4",
            "name": "luminated"
        },
        {
            "id": "5",
            "name": "free-standing"
        },
        {
            "id": "6",
            "name": "wall-mounted"
        },
        {
            "id": "7",
            "name": "wall-standing"
        },
        {
            "id": "8",
            "name": "wall-leaning"
        },
        {
            "id": "9",
            "name": "ceiling-mounted"
        },
        {
            "id": "10",
            "name": "Grab rails"
        },
        {
            "id": "11",
            "name": "Towel rails"
        },
        {
            "id": "12"
        },
        {
            "id": "13",
            "name": "Towel rails"
        },
        {
            "id": "14",
            "name": "Towel rings"
        },
        {
            "id": "15",
            "name": "Towel racks"
        },
        {
            "id": "16",
            "name": "Towel hooks"
        },
        {
            "id": "17",
            "name": "Soap dispensers"
        },
        {
            "id": "18",
            "name": "Soap holders / dishes"
        },
        {
            "id": "19",
            "name": "Sponge baskets"
        },
        {
            "id": "20",
            "name": "Toothbrush holders"
        },
        {
            "id": "21",
            "name": "Bath shelves"
        },
        {
            "id": "22",
            "name": "Paper towel dispensers"
        },
        {
            "id": "23",
            "name": "Hygiene bag dispensers"
        },
        {
            "id": "24",
            "name": "Beauty accessory storage"
        },
        {
            "id": "25",
            "name": "Paper roll holders"
        },
        {
            "id": "26",
            "name": "Toilet brush holders"
        },
        {
            "id": "27",
            "name": "Toilet-stands"
        },
        {
            "id": "28",
            "name": "Bath waste bins"
        },
        {
            "id": "29",
            "name": "Laundry baskets"
        },
        {
            "id": "30",
            "name": "Washing lines"
        },
        {
            "id": "31",
            "name": "Hand dryers"
        },
        {
            "id": "32",
            "name": "Hair dryers"
        },
        {
            "id": "33",
            "name": "Shower seats"
        },
        {
            "id": "34",
            "name": "Shower curtains"
        },
        {
            "id": "35",
            "name": "Shower curtain rails"
        }
];

var shapes= [
        {
            "id": "1",
            "name": "Nonagon"
        },
        {
            "id": "2",
            "name": "Octagon"
        },
        {
            "id": "3",
            "name": "Heptagon"
        },
        {
            "id": "4",
            "name": "Hexagon"
        },
        {
            "id": "5",
            "name": "Triangle"
        },
        {
            "id": "6",
            "name": "Scalene triangle"
        },
        {
            "id": "7",
            "name": "Right triangle"
        },
        {
            "id": "8",
            "name": "Parallelogram"
        },
        {
            "id": "9",
            "name": "Rhombus"
        },
        {
            "id": "10",
            "name": "Square"
        },
        {
            "id": "11",
            "name": "Pentagon"
        },
        {
            "id": "12",
            "name": "Circle"
        },
        {
            "id": "13",
            "name": "Oval"
        },
        {
            "id": "14",
            "name": "Heart"
        },
        {
            "id": "15",
            "name": "Cross"
        },
        {
            "id": "16",
            "name": "Arrow"
        },
        {
            "id": "17",
            "name": "Cube"
        },
        {
            "id": "18",
            "name": "Cylinder"
        },
        {
            "id": "19",
            "name": "Star"
        },
        {
            "id": "20",
            "name": "Crescent"
        }
];

var days= [
        {
            "id": "1",
            "name": "Mondays"
        },
        {
            "id": "2",
            "name": "Tuesdays"
        },
        {
            "id": "3",
            "name": "Wednesdays"
        },
        {
            "id": "4",
            "name": "Thursdays"
        },
        {
            "id": "5",
            "name": "Fridays"
        },
        {
            "id": "6",
            "name": "Saturdays"
        },
        {
            "id": "7",
            "name": "Sundays"
        }
];

var stationary = [
        {
            "id": "1",
            "name": "Stapler"
        },
        {
            "id": "2",
            "name": "Eraser"
        },
        {
            "id": "3",
            "name": "Push-pin"
        },
        {
            "id": "4",
            "name": "Drawing pin (U.K)/ Thumbtack (U.S)"
        },
        {
            "id": "5",
            "name": "Paper clip"
        },
        {
            "id": "6",
            "name": "Rubber stamp"
        },
        {
            "id": "7",
            "name": "Highlighter"
        },
        {
            "id": "8",
            "name": "Fountain pen"
        },
        {
            "id": "9",
            "name": "Pencil"
        },
        {
            "id": "10",
            "name": "Marker"
        },
        {
            "id": "11",
            "name": "Ballpoint"
        },
        {
            "id": "12",
            "name": "Bulldog clip"
        },
        {
            "id": "13",
            "name": "Tape dispenser"
        },
        {
            "id": "14",
            "name": "Pencil sharpener"
        },
        {
            "id": "15",
            "name": "Label"
        },
        {
            "id": "16",
            "name": "Calculator"
        },
        {
            "id": "17",
            "name": "Glue"
        },
        {
            "id": "18",
            "name": "Scissors"
        },
        {
            "id": "19",
            "name": "Sticky notes"
        },
        {
            "id": "20",
            "name": "Paper"
        },
        {
            "id": "21",
            "name": "Notebook"
        },
        {
            "id": "22",
            "name": "Envelope"
        },
        {
            "id": "23",
            "name": "Clipboard"
        },
        {
            "id": "24",
            "name": "Monitor"
        },
        {
            "id": "25",
            "name": "Computer"
        },
        {
            "id": "26",
            "name": "Keyboard"
        },
        {
            "id": "27",
            "name": "Folder"
        },
        {
            "id": "28",
            "name": "Fax"
        },
        {
            "id": "29",
            "name": "Filing cabinet"
        },
        {
            "id": "30",
            "name": "Telephone"
        },
        {
            "id": "31",
            "name": "Swivel chair"
        },
        {
            "id": "32",
            "name": "Desk"
        },
        {
            "id": "33",
            "name": "Wastebasket"
        }
];

var occuption_kids = [
        {
            "id": "1",
            "name": "Waiter"
        },
        {
            "id": "2",
            "name": "Paramedic"
        },
        {
            "id": "3",
            "name": "Dentist"
        },
        {
            "id": "4",
            "name": "Train conductor"
        },
        {
            "id": "5",
            "name": "Nurse"
        },
        {
            "id": "6",
            "name": "Electrician"
        },
        {
            "id": "7",
            "name": "Doctor"
        },
        {
            "id": "8",
            "name": "Businessman"
        },
        {
            "id": "9",
            "name": "American football player"
        },
        {
            "id": "10",
            "name": "Student"
        },
        {
            "id": "11",
            "name": "Surgeon"
        },
        {
            "id": "12",
            "name": "Doorman"
        },
        {
            "id": "13",
            "name": "Secretary"
        },
        {
            "id": "14",
            "name": "Soldier"
        },
        {
            "id": "15",
            "name": "Repairman"
        },
        {
            "id": "16",
            "name": "Scientist"
        },
        {
            "id": "17",
            "name": "Reporter"
        },
        {
            "id": "18",
            "name": "Construction worker"
        },
        {
            "id": "19",
            "name": "Professor"
        },
        {
            "id": "20",
            "name": "Police officer"
        },
        {
            "id": "21",
            "name": "Postman"
        },
        {
            "id": "22",
            "name": "Photographer"
        },
        {
            "id": "23",
            "name": "Pilot"
        },
        {
            "id": "24",
            "name": "Catholic nun"
        },
        {
            "id": "25",
            "name": "Painter"
        },
        {
            "id": "26",
            "name": "Mechanic"
        },
        {
            "id": "27",
            "name": "Magician"
        },
        {
            "id": "28",
            "name": "Lifeguard"
        },
        {
            "id": "29",
            "name": "Lunchroom supervisor"
        },
        {
            "id": "30",
            "name": "Clown"
        },
        {
            "id": "31",
            "name": "Housekeeper"
        },
        {
            "id": "32",
            "name": "Gardener"
        },
        {
            "id": "33",
            "name": "Geisha"
        },
        {
            "id": "34",
            "name": "Footballer"
        },
        {
            "id": "35",
            "name": "Forest ranger"
        },
        {
            "id": "36",
            "name": "Builder"
        },
        {
            "id": "37",
            "name": "Foreman"
        },
        {
            "id": "38",
            "name": "Farmer"
        },
        {
            "id": "39",
            "name": "Flight attendant"
        },
        {
            "id": "40",
            "name": "Fireman"
        },
        {
            "id": "41",
            "name": "Engineer"
        },
        {
            "id": "42",
            "name": "Carpenter"
        },
        {
            "id": "43",
            "name": "Architect"
        },
        {
            "id": "44",
            "name": "Boxer"
        },
        {
            "id": "45",
            "name": "Cameraman"
        },
        {
            "id": "46",
            "name": "Detective"
        },
        {
            "id": "47",
            "name": "Journalist"
        },
        {
            "id": "48",
            "name": "Housewife"
        },
        {
            "id": "49",
            "name": "Diver"
        },
        {
            "id": "50",
            "name": "Pope"
        },
        {
            "id": "51",
            "name": "Priest"
        },
        {
            "id": "52",
            "name": "Salesman"
        },
        {
            "id": "53",
            "name": "Librarian"
        },
        {
            "id": "54",
            "name": "Pirate"
        },
        {
            "id": "55",
            "name": "Singer"
        }
    ];


var insect =  [
        {
            "id": "1",
            "name": "Alderflies"
        },
        {
            "id": "2",
            "name": "Ants"
        },
        {
            "id": "3",
            "name": "Antlions"
        },
        {
            "id": "4",
            "name": "Archaeognatha"
        },
        {
            "id": "5",
            "name": "Barklice"
        },
        {
            "id": "6",
            "name": "Bees"
        },
        {
            "id": "7",
            "name": "Beetles"
        },
        {
            "id": "8",
            "name": "Biting lice"
        },
        {
            "id": "9",
            "name": "Booklice"
        },
        {
            "id": "10",
            "name": "Butterflies"
        },
        {
            "id": "11",
            "name": "Bugs"
        },
        {
            "id": "12",
            "name": "Caddisflies"
        },
        {
            "id": "13",
            "name": "Cockroaches"
        },
        {
            "id": "14",
            "name": "Crickets"
        },
        {
            "id": "15",
            "name": "Damselflies"
        },
        {
            "id": "16",
            "name": "Dobsonflies"
        },
        {
            "id": "17",
            "name": "Dragonflies"
        },
        {
            "id": "18",
            "name": "Earwigs"
        },
        {
            "id": "19",
            "name": "Fleas"
        },
        {
            "id": "20",
            "name": "Flies"
        },
        {
            "id": "21",
            "name": "Grasshoppers"
        },
        {
            "id": "22",
            "name": "Lacewings"
        },
        {
            "id": "23",
            "name": "Leaf insects"
        },
        {
            "id": "24",
            "name": "Lice"
        },
        {
            "id": "25",
            "name": "Mantids"
        },
        {
            "id": "26",
            "name": "Mayflies"
        },
        {
            "id": "27",
            "name": "Moths"
        },
        {
            "id": "28",
            "name": "Praying Mantids"
        },
        {
            "id": "29",
            "name": "Scorpionflies"
        },
        {
            "id": "30",
            "name": "Snakeflies"
        },
        {
            "id": "31",
            "name": "Stick insects"
        },
        {
            "id": "32",
            "name": "Stoneflies"
        },
        {
            "id": "33",
            "name": "Strepsipterans"
        },
        {
            "id": "34",
            "name": "Sucking lice"
        },
        {
            "id": "35",
            "name": "Termites"
        },
        {
            "id": "36",
            "name": "Three-pronged bristletails"
        },
        {
            "id": "37",
            "name": "Thrips"
        },
        {
            "id": "38",
            "name": "True Bugs"
        },
        {
            "id": "39",
            "name": "Wasps"
        },
        {
            "id": "40",
            "name": "Web-spinners"
        },
        {
            "id": "41",
            "name": "Zorapterans"
        },
        {
            "id": "42",
            "name": "Proturans"
        },
        {
            "id": "43",
            "name": "Springtails"
        },
        {
            "id": "44",
            "name": "Two-pronged bristletails"
        },
        {
            "id": "45",
            "name": "Army ants"
        },
        {
            "id": "46",
            "name": "Bumble bees"
        },
        {
            "id": "47",
            "name": "Cicadas"
        },
        {
            "id": "48",
            "name": "Darner dragonflies"
        },
        {
            "id": "49",
            "name": "Earwigs"
        },
        {
            "id": "50",
            "name": "Fireflies"
        },
        {
            "id": "51",
            "name": "Grasshoppers"
        },
        {
            "id": "52",
            "name": "Hummingbird moths"
        },
        {
            "id": "53",
            "name": "Ichneumonid wasps"
        },
        {
            "id": "54",
            "name": "Jewel beetles"
        },
        {
            "id": "55",
            "name": "Katydids"
        },
        {
            "id": "56",
            "name": "Lacewings"
        },
        {
            "id": "57",
            "name": "Mosquitoes"
        },
        {
            "id": "58",
            "name": "Net-winged midges"
        },
        {
            "id": "59",
            "name": "Owlflies"
        },
        {
            "id": "60",
            "name": "Paper wasps"
        },
        {
            "id": "61",
            "name": "Queen termites"
        },
        {
            "id": "62",
            "name": "Robber flies"
        },
        {
            "id": "63",
            "name": "Spider wasps"
        },
        {
            "id": "64",
            "name": "Tiger beetles"
        },
        {
            "id": "65",
            "name": "Urania moths"
        },
        {
            "id": "66",
            "name": "Viceroy butterflies"
        },
        {
            "id": "67",
            "name": "Weevils"
        },
        {
            "id": "68",
            "name": "Xylocopid bees"
        },
        {
            "id": "69",
            "name": "Yucca moths"
        },
        {
            "id": "70",
            "name": "Zebra clubtails."
        }
];

var computer_parts = [
        {
            "id": "1",
            "name": "Graphics Tablets"
        },
        {
            "id": "2",
            "name": "Video Capture Hardware"
        },
        {
            "id": "3",
            "name": "Trackballs"
        },
        {
            "id": "4",
            "name": "Barcode reader"
        },
        {
            "id": "5",
            "name": "Digital camera"
        },
        {
            "id": "6",
            "name": "MIDI keyboard"
        },
        {
            "id": "7",
            "name": "Gamepad"
        },
        {
            "id": "8",
            "name": "Joystick"
        },
        {
            "id": "9",
            "name": "Keyboard"
        },
        {
            "id": "10",
            "name": "Cameras"
        },
        {
            "id": "11",
            "name": "Microphone"
        },
        {
            "id": "12",
            "name": "Mouse (pointing device)"
        },
        {
            "id": "13",
            "name": "Scanner"
        },
        {
            "id": "14",
            "name": "Webcam"
        },
        {
            "id": "15",
            "name": "Touchpad’s"
        },
        {
            "id": "16",
            "name": "Microphone"
        },
        {
            "id": "17",
            "name": "Electronic Whiteboard"
        },
        {
            "id": "18",
            "name": "OMR"
        },
        {
            "id": "19",
            "name": "OCR"
        },
        {
            "id": "20",
            "name": "Pen Input"
        },
        {
            "id": "21",
            "name": "Punch card reader"
        },
        {
            "id": "22",
            "name": "MICR (Magnetic Ink character reader)"
        },
        {
            "id": "23",
            "name": "Magnetic Tape Drive"
        },
        {
            "id": "24",
            "name": "LCD Projection Panels"
        },
        {
            "id": "25",
            "name": "Touch Screen"
        },
        {
            "id": "26",
            "name": "Modems"
        },
        {
            "id": "27",
            "name": "Network cards"
        },
        {
            "id": "28",
            "name": "Audio Cards / Sound Card"
        },
        {
            "id": "29",
            "name": "Headsets (Headset consists of Speakers and Microphone."
        },
        {
            "id": "30",
            "name": "Speaker act Output Device and Microphone act as Input device"
        },
        {
            "id": "31",
            "name": "Facsimile (FAX)  (It has scanner to scan the document and also have printer to Print the document)"
        },
        {
            "id": "32",
            "name": "Speaker(s)"
        },
        {
            "id": "33",
            "name": "Visual Display Unit"
        },
        {
            "id": "34",
            "name": "Film Recorder"
        }
];

var good_habit =  [
        {
            "id": "1",
            "name": "Sit when eating food"
        },
        {
            "id": "2",
            "name": " Eating with the mouth closed"
        },
        {
            "id": "3",
            "name": "Don’t be fussy about food"
        },
        {
            "id": "4",
            "name": " Eating right"
        },
        {
            "id": "5",
            "name": " Washing hands before eating"
        },
        {
            "id": "6",
            "name": " Dental hygiene and care"
        },
        {
            "id": "7",
            "name": "Take a bath before you step out of the house"
        },
        {
            "id": "8",
            "name": "Washing your hands and feet after using the toilet"
        },
        {
            "id": "9",
            "name": "Getting out of the house to play"
        },
        {
            "id": "10",
            "name": "Greeting people when you meet"
        },
        {
            "id": "11",
            "name": "Always excusing yourself when you want to leave the table"
        },
        {
            "id": "12",
            "name": "Help clean up after mealtime"
        },
        {
            "id": "13",
            "name": "Always thank the person who has prepared the meal"
        },
        {
            "id": "14",
            "name": "Keeping their room clean"
        },
        {
            "id": "15",
            "name": "Sleep on time"
        },
        {
            "id": "16",
            "name": "Learning to be responsible with money"
        },
        {
            "id": "17",
            "name": " Do not litter"
        },
        {
            "id": "18",
            "name": "A little bit of reading every day"
        },
        {
            "id": "19",
            "name": " Treat people with respect"
        },
        {
            "id": "20",
            "name": "Always be honest"
        },
        {
            "id": "21",
            "name": "Everyone should be treated equally"
        },
        {
            "id": "22",
            "name": "Be patient"
        },
        {
            "id": "23",
            "name": "Don’t be a spoilsport"
        },
        {
            "id": "24",
            "name": "Spend time with the family"
        },
        {
            "id": "25",
            "name": "Do not bully or tease people"
        },
        {
            "id": "26",
            "name": "Be kind to birds and animals"
        },
        {
            "id": "27",
            "name": "Stand in a queue patiently"
        },
        {
            "id": "28",
            "name": "Stay organized"
        },
        {
            "id": "29",
            "name": "Clip your Nails"
        },
        {
            "id": "30",
            "name": "Never leave food in your plate"
        },
        {
            "id": "31",
            "name": " Be Punctual  "
        },
        {
            "id": "32",
            "name": "Prepare for the next day at night"
        },
        {
            "id": "33",
            "name": "Always help people"
        },
        {
            "id": "34",
            "name": "Respect your elders"
        },
        {
            "id": "35",
            "name": "Discuss problems with those you trust"
        },
        {
            "id": "36",
            "name": "Exercise often"
        },
        {
            "id": "37",
            "name": "No Yelling"
        },
        {
            "id": "38",
            "name": "Healthy Lifestyle"
        },
        {
            "id": "39",
            "name": "Waiting for their Turn"
        },
        {
            "id": "40",
            "name": "To find fault"
        },
        {
            "id": "41",
            "name": "Brushing Twice a Day"
        }
    ];